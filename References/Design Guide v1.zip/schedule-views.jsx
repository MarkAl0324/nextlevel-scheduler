// Schedule views — Roster (table), Month (calendar), Matrix (provider-centric).
// Reads data from window.NLS_DATA.

const { providers, staff, days, dates, roster, swaps } = window.NLS_DATA;
const { providerById } = window.NLS_helpers;

const tabs = [
  { id: "roster", icon: "table",    label: "Roster" },
  { id: "month",  icon: "calendar", label: "Month" },
  { id: "matrix", icon: "grid",     label: "Matrix" },
];

const ScheduleHeader = ({ active }) => (
  <>
    <Topbar
      title="My schedule"
      subtitle={`Mar 17 – 21 · ${staff.length} staff`}
      week="Mar 17 – 21"
    />
    <SubNav active={active} tabs={tabs.map((t) => ({ ...t }))} />
    <div style={{ padding: "16px 24px 12px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <Input placeholder="Filter staff or provider…" icon="search" style={{ width: 240 }} />
        <Button variant="secondary" icon="filter">All providers</Button>
        <Button variant="ghost" size="md">Show swaps only</Button>
      </div>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <span style={{ fontSize: 12, color: "var(--nls-text-subtle)" }}>
          <span className="nls-num">6</span> open swaps · <span className="nls-num">3</span> approvals pending
        </span>
        <Button variant="primary" icon="plus">Post a swap</Button>
      </div>
    </div>
  </>
);

// ────────────────────────────────────────────────────────────────
// ROSTER — table layout, staff × weekday
// ────────────────────────────────────────────────────────────────
const TODAY_IDX = 1; // Tuesday (Mar 18) is "today" in the demo

const RosterCell = ({ person, dayIdx }) => {
  const provId = roster[person.id][dayIdx];
  const swapKey = `${person.id}/${days[dayIdx]}`;
  const swapStatus = swaps[swapKey];
  const today = dayIdx === TODAY_IDX;

  if (provId === null) {
    return <AssignmentCell tone="empty" label="Off" sub="Day off" compact />;
  }
  if (provId === "—") {
    return <AssignmentCell tone="holiday" label="Front desk" compact />;
  }
  const p = providerById(provId);
  let tone = today ? "today" : "default";
  let chip;
  if (swapStatus === "open") { tone = "swap-open"; chip = "Posted"; }
  if (swapStatus === "pending") { tone = "swap-pending"; chip = "Proposals"; }
  if (swapStatus === "approved") { tone = "approved"; chip = "Swap approved"; }

  return (
    <AssignmentCell tone={tone} label={p.short} sub={p.specialty} chip={chip} compact />
  );
};

const RosterArtboard = ({ theme = "light", role = "manager" }) => (
  <Shell theme={theme} role={role} active="schedule"
    topbar={null}
    subnav={null}
  >
    {/* override the default Shell main padding by replacing topbar+subnav inside main */}
    <div style={{ margin: "-20px -24px 0", display: "flex", flexDirection: "column" }}>
      <ScheduleHeader active="roster" />
      <div style={{ padding: "0 24px 24px", overflow: "auto" }}>
        <Card padded={false} style={{ overflow: "hidden" }}>
          {/* table header */}
          <div style={{
            display: "grid", gridTemplateColumns: "220px repeat(5, 1fr)",
            background: "var(--nls-bg-tint)", borderBottom: "1px solid var(--nls-divider)",
          }}>
            <div style={{ padding: "10px 14px", fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>
              Staff
            </div>
            {days.map((d, i) => (
              <div key={d} style={{
                padding: "10px 12px",
                fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase",
                color: i === TODAY_IDX ? "var(--nls-accent)" : "var(--nls-text-subtle)",
                borderLeft: "1px solid var(--nls-divider)",
                display: "flex", alignItems: "center", gap: 8,
              }}>
                <span>{d}</span>
                <span style={{ fontSize: 11, fontWeight: 500, textTransform: "none", letterSpacing: 0, color: i === TODAY_IDX ? "var(--nls-accent)" : "var(--nls-text-muted)" }} className="nls-num">
                  {dates[i]}{i === TODAY_IDX && " · Today"}
                </span>
              </div>
            ))}
          </div>

          {/* rows */}
          {staff.map((person, ri) => (
            <div key={person.id} style={{
              display: "grid", gridTemplateColumns: "220px repeat(5, 1fr)",
              borderBottom: ri < staff.length - 1 ? "1px solid var(--nls-divider)" : "none",
            }}>
              <div style={{
                padding: "10px 14px", display: "flex", alignItems: "center", gap: 10,
                background: person.id === "maya" ? "var(--nls-accent-soft)" : "transparent",
                borderRight: "1px solid var(--nls-divider)",
              }}>
                <Avatar initials={person.initials} hue={`var(--nls-role-${person.role.toLowerCase() === "front" ? "front" : person.role.toLowerCase()})`} size={28} />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>
                    {person.first}{person.id === "maya" && " (You)"}
                  </div>
                  <div style={{ fontSize: 11, color: "var(--nls-text-muted)" }}>{person.name.split(" ")[1]} · {person.role}</div>
                </div>
              </div>
              {days.map((d, di) => (
                <div key={d} style={{ padding: 6, borderLeft: "1px solid var(--nls-divider)" }}>
                  <RosterCell person={person} dayIdx={di} />
                </div>
              ))}
            </div>
          ))}
        </Card>

        <div style={{ marginTop: 12, fontSize: 11, color: "var(--nls-text-subtle)", display: "flex", gap: 16, flexWrap: "wrap", alignItems: "center" }}>
          <LegendDot label="Today" color="var(--nls-accent)" />
          <LegendDot label="Open swap" color="var(--nls-warning)" />
          <LegendDot label="Proposals received" color="var(--nls-accent)" />
          <LegendDot label="Swap approved" color="var(--nls-success)" />
          <LegendDot label="Day off" dashed />
        </div>
      </div>
    </div>
  </Shell>
);

const LegendDot = ({ label, color, dashed }) => (
  <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
    <span style={{
      width: 12, height: 12, borderRadius: 3,
      background: dashed ? "transparent" : "color-mix(in oklab, " + (color || "var(--nls-text-muted)") + " 18%, var(--nls-surface))",
      border: dashed
        ? "1px dashed var(--nls-border-strong)"
        : `1px solid ${color || "var(--nls-text-muted)"}`,
    }} />
    <span>{label}</span>
  </span>
);

// ────────────────────────────────────────────────────────────────
// MONTH — calendar grid
// ────────────────────────────────────────────────────────────────
// Generate 5 weeks of March. Each day = compact summary.
const MONTH_DAYS = (() => {
  const days = [];
  // March 2026: Mar 1 is Sunday. Show full month + lead/trail.
  for (let i = 0; i < 35; i++) {
    const d = i - 0; // Mar 1 is at index 0
    let date, muted = false;
    if (d < 1) { date = 28 + d; muted = true; } // Feb tail
    else if (d > 31) { date = d - 31; muted = true; }
    else { date = d; }
    days.push({ date, muted, idx: i });
  }
  return days;
})();

const monthDayData = (date) => {
  // Demo: my (Maya) assignments week of Mar 17. Fill in other days lightly.
  if (date === 17) return { mine: { prov: "Patel", color: "#2563eb" }, swaps: 0 };
  if (date === 18) return { mine: { prov: "Patel", color: "#2563eb" }, swaps: 1, today: true };
  if (date === 19) return { off: true };
  if (date === 20) return { mine: { prov: "Okafor", color: "#dc2626" }, posted: true };
  if (date === 21) return { mine: { prov: "Okafor", color: "#dc2626" }, swaps: 2 };
  if (date >= 23 && date <= 27) {
    const map = { 23: "Patel", 24: "Patel", 25: "Off", 26: "Okafor", 27: "Okafor" };
    if (map[date] === "Off") return { off: true };
    return { mine: { prov: map[date], color: map[date] === "Patel" ? "#2563eb" : "#dc2626" } };
  }
  if (date === 9 || date === 10 || date === 11 || date === 13 || date === 14) return { past: true, prov: "Patel" };
  if (date === 12) return { past: true, prov: "Okafor" };
  if (date === 30) return { mine: { prov: "Patel", color: "#2563eb" } };
  if (date === 31) return { mine: { prov: "Patel", color: "#2563eb" } };
  return {};
};

const MonthCell = ({ day, weekdayIdx }) => {
  const data = monthDayData(day.date);
  const isWeekend = weekdayIdx === 0 || weekdayIdx === 6;
  return (
    <div style={{
      minHeight: 92, padding: 8,
      borderRight: weekdayIdx === 6 ? "none" : "1px solid var(--nls-divider)",
      borderBottom: "1px solid var(--nls-divider)",
      background: day.muted ? "var(--nls-bg-tint)" : "var(--nls-surface)",
      opacity: day.muted ? 0.5 : 1,
      display: "flex", flexDirection: "column", gap: 4,
      position: "relative",
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span
          className="nls-num"
          style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 22, height: 22, borderRadius: "50%",
            fontSize: 12, fontWeight: data.today ? 600 : 500,
            background: data.today ? "var(--nls-accent)" : "transparent",
            color: data.today ? "#fff" : (isWeekend ? "var(--nls-text-subtle)" : "var(--nls-text)"),
          }}
        >{day.date}</span>
        {data.swaps > 0 && (
          <span style={{
            fontSize: 10, fontWeight: 600, color: "var(--nls-accent)",
            display: "inline-flex", alignItems: "center", gap: 2,
          }}>
            <Icon name="swap" size={10} />
            {data.swaps}
          </span>
        )}
      </div>

      {data.mine && !data.off && (
        <div style={{
          padding: "4px 6px", borderRadius: 5, fontSize: 11, fontWeight: 500,
          display: "flex", alignItems: "center", gap: 5,
          background: data.posted ? "var(--nls-warning-soft)" : "var(--nls-surface-hover)",
          borderLeft: `3px solid ${data.posted ? "var(--nls-warning)" : data.mine.color}`,
          color: "var(--nls-text-strong)",
        }}>
          <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Dr. {data.mine.prov}</span>
        </div>
      )}
      {data.posted && (
        <div style={{ fontSize: 10, color: "var(--nls-warning)", fontWeight: 500, display: "flex", alignItems: "center", gap: 4 }}>
          <Icon name="dot" size={8} /> Swap posted
        </div>
      )}
      {data.off && <div style={{ fontSize: 11, color: "var(--nls-text-subtle)", fontStyle: "italic" }}>Day off</div>}
      {data.past && (
        <div style={{
          fontSize: 11, color: "var(--nls-text-subtle)",
          padding: "3px 6px", background: "var(--nls-bg-tint)", borderRadius: 4,
        }}>Dr. {data.prov}</div>
      )}
    </div>
  );
};

const MonthArtboard = ({ theme = "light" }) => (
  <Shell theme={theme} active="schedule"
    topbar={null} subnav={null}
  >
    <div style={{ margin: "-20px -24px 0", display: "flex", flexDirection: "column", height: "calc(100% + 32px)" }}>
      <ScheduleHeader active="month" />

      <div style={{ padding: "0 24px 24px", overflow: "auto", flex: 1 }}>
        {/* month switcher */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <h3 style={{ fontSize: 18, fontWeight: 600 }}>March 2026</h3>
            <Badge tone="accent" size="md">9 shifts this month</Badge>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <Button variant="ghost" size="sm">Today</Button>
            <button style={iconBtnSm}><Icon name="chevronLeft" size={14} color="var(--nls-text-muted)" /></button>
            <button style={iconBtnSm}><Icon name="chevronRight" size={14} color="var(--nls-text-muted)" /></button>
          </div>
        </div>

        <Card padded={false} style={{ overflow: "hidden" }}>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(7, 1fr)",
            background: "var(--nls-bg-tint)", borderBottom: "1px solid var(--nls-divider)",
          }}>
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
              <div key={d} style={{
                padding: "10px 12px",
                fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase",
                color: "var(--nls-text-subtle)",
              }}>{d}</div>
            ))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)" }}>
            {MONTH_DAYS.map((day, i) => (
              <MonthCell key={i} day={day} weekdayIdx={i % 7} />
            ))}
          </div>
        </Card>
      </div>
    </div>
  </Shell>
);

const iconBtnSm = {
  width: 28, height: 28, border: "1px solid var(--nls-border)", background: "var(--nls-surface)",
  borderRadius: 6, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
};

// ────────────────────────────────────────────────────────────────
// MATRIX — providers × dates → who's assigned
// ────────────────────────────────────────────────────────────────
const MatrixCell = ({ provId, dayIdx }) => {
  // Find which staff have this provider on this day
  const assigned = staff.filter((s) => roster[s.id][dayIdx] === provId);
  const today = dayIdx === TODAY_IDX;

  if (assigned.length === 0) {
    return (
      <div style={{
        padding: "10px 12px", minHeight: 56,
        background: "transparent", borderLeft: "1px solid var(--nls-divider)",
        borderTop: today ? "2px solid var(--nls-accent)" : "none",
        display: "flex", alignItems: "center", gap: 6,
      }}>
        <div style={{
          padding: "6px 8px", borderRadius: 6,
          border: "1px dashed var(--nls-danger)",
          color: "var(--nls-danger)", fontSize: 11, fontWeight: 500,
          background: "var(--nls-danger-soft)",
          display: "inline-flex", alignItems: "center", gap: 5,
        }}>
          <Icon name="alert" size={11} /> Unassigned
        </div>
      </div>
    );
  }

  return (
    <div style={{
      padding: "8px 10px", minHeight: 56,
      borderLeft: "1px solid var(--nls-divider)",
      borderTop: today ? "2px solid var(--nls-accent)" : "none",
      background: today ? "var(--nls-accent-soft)" : "transparent",
      display: "flex", flexDirection: "column", gap: 4,
    }}>
      {assigned.map((s) => {
        const swapKey = `${s.id}/${days[dayIdx]}`;
        const sw = swaps[swapKey];
        return (
          <div key={s.id} style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "4px 6px 4px 4px", borderRadius: 999,
            background: "var(--nls-surface)",
            border: "1px solid var(--nls-border)",
            fontSize: 12, color: "var(--nls-text-strong)",
            width: "fit-content",
          }}>
            <Avatar initials={s.initials} hue={`var(--nls-role-${s.role.toLowerCase() === "front" ? "front" : s.role.toLowerCase()})`} size={20} />
            <span style={{ fontWeight: 500 }}>{s.first}</span>
            {sw === "open"     && <span style={{ width: 6, height: 6, borderRadius: 3, background: "var(--nls-warning)" }} />}
            {sw === "pending"  && <span style={{ width: 6, height: 6, borderRadius: 3, background: "var(--nls-accent)" }} />}
            {sw === "approved" && <Icon name="check" size={11} color="var(--nls-success)" />}
          </div>
        );
      })}
    </div>
  );
};

const MatrixArtboard = ({ theme = "light" }) => (
  <Shell theme={theme} active="schedule" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0", display: "flex", flexDirection: "column" }}>
      <ScheduleHeader active="matrix" />

      <div style={{ padding: "0 24px 24px", overflow: "auto" }}>
        <Card padded={false} style={{ overflow: "hidden" }}>
          <div style={{
            display: "grid", gridTemplateColumns: "240px repeat(5, 1fr)",
            background: "var(--nls-bg-tint)", borderBottom: "1px solid var(--nls-divider)",
          }}>
            <div style={{ padding: "10px 14px", fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>
              Provider
            </div>
            {days.map((d, i) => (
              <div key={d} style={{
                padding: "10px 12px",
                fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase",
                color: i === TODAY_IDX ? "var(--nls-accent)" : "var(--nls-text-subtle)",
                borderLeft: "1px solid var(--nls-divider)",
              }}>{d} · <span className="nls-num" style={{ fontWeight: 500, textTransform: "none", letterSpacing: 0 }}>{dates[i]}</span></div>
            ))}
          </div>

          {providers.map((p, ri) => (
            <div key={p.id} style={{
              display: "grid", gridTemplateColumns: "240px repeat(5, 1fr)",
              borderBottom: ri < providers.length - 1 ? "1px solid var(--nls-divider)" : "none",
            }}>
              <div style={{
                padding: "12px 14px", display: "flex", alignItems: "center", gap: 10,
                borderRight: "1px solid var(--nls-divider)",
                background: "var(--nls-surface)",
              }}>
                <span style={{
                  width: 6, height: 36, borderRadius: 3, background: p.color, flex: "0 0 6px",
                }} />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>{p.name}</div>
                  <div style={{ fontSize: 11, color: "var(--nls-text-muted)" }}>{p.specialty}</div>
                </div>
              </div>
              {days.map((_, di) => <MatrixCell key={di} provId={p.id} dayIdx={di} />)}
            </div>
          ))}
        </Card>

        <div style={{
          marginTop: 14, padding: 14,
          background: "var(--nls-danger-soft)",
          border: "1px solid var(--nls-danger)", borderLeftWidth: 3,
          borderRadius: 8,
          display: "flex", alignItems: "center", gap: 12,
        }}>
          <Icon name="alert" size={18} color="var(--nls-danger)" />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)" }}>2 unassigned cells this week</div>
            <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>Dr. Reyes is unstaffed Tue and Thu. Pairing rules suggest Devon or Theo.</div>
          </div>
          <Button variant="secondary" size="sm">Open editor</Button>
        </div>
      </div>
    </div>
  </Shell>
);

Object.assign(window, { RosterArtboard, MonthArtboard, MatrixArtboard });
