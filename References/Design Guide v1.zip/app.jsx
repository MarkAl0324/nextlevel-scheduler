// Main canvas composition. Wires up all artboards + Tweaks panel.

const { useEffect: useAppEffect, useState: useAppState } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#2563eb",
  "role": "manager",
  "density": "comfortable",
  "scheduleView": "roster"
}/*EDITMODE-END*/;

const ACCENT_OPTIONS = [
  "#2563eb", // Notion blue (default)
  "#0d9488", // clinic teal
  "#7c3aed", // plum
  "#b45309", // amber
  "#1f2937", // ink
];
// Per-accent overrides for the soft companion + accent dark twin
const ACCENT_VARS = {
  "#2563eb": { hover: "#1d4ed8", soft: "#eff6ff", strong: "#1e40af", dark: "#60a5fa", darkSoft: "rgba(96,165,250,.14)" },
  "#0d9488": { hover: "#0f766e", soft: "#ccfbf1", strong: "#115e59", dark: "#5eead4", darkSoft: "rgba(94,234,212,.14)" },
  "#7c3aed": { hover: "#6d28d9", soft: "#ede9fe", strong: "#5b21b6", dark: "#c4b5fd", darkSoft: "rgba(196,181,253,.14)" },
  "#b45309": { hover: "#92400e", soft: "#fef3c7", strong: "#78350f", dark: "#fbbf24", darkSoft: "rgba(251,191,36,.14)" },
  "#1f2937": { hover: "#111827", soft: "#f3f4f6", strong: "#111827", dark: "#cbd5e1", darkSoft: "rgba(203,213,225,.14)" },
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply accent + density as CSS overrides on every .nls-scope so all
  // artboards re-color in lockstep.
  useAppEffect(() => {
    const id = "nls-tweak-style";
    let el = document.getElementById(id);
    if (!el) { el = document.createElement("style"); el.id = id; document.head.appendChild(el); }
    const a = ACCENT_VARS[t.accent] || ACCENT_VARS["#2563eb"];
    el.textContent = `
      .nls-scope {
        --nls-accent: ${t.accent};
        --nls-accent-hover: ${a.hover};
        --nls-accent-soft: ${a.soft};
        --nls-accent-strong: ${a.strong};
      }
      .nls-scope[data-theme="dark"] {
        --nls-accent: ${a.dark};
        --nls-accent-hover: ${a.dark};
        --nls-accent-soft: ${a.darkSoft};
        --nls-accent-strong: ${a.dark};
      }
    `;
  }, [t.accent]);

  // Density attr
  useAppEffect(() => {
    document.querySelectorAll(".nls-scope").forEach((n) => {
      if (t.density === "compact") n.setAttribute("data-density", "compact");
      else n.removeAttribute("data-density");
    });
  });

  // pick which schedule artboard to render
  const ScheduleByTweak = ({ theme = "light" }) => {
    if (t.scheduleView === "month")  return <MonthArtboard theme={theme} />;
    if (t.scheduleView === "matrix") return <MatrixArtboard theme={theme} />;
    return <RosterArtboard theme={theme} role={t.role} />;
  };

  return (
    <>
      <DesignCanvas>
        {/* ───── Foundations ───── */}
        <DCSection id="foundations" title="Foundations" subtitle="Design tokens · color, type, shape, icons">
          <DCArtboard id="cover"   label="Brand · cover"            width={620} height={620}><BrandCover /></DCArtboard>
          <DCArtboard id="col-l"   label="Color · light"            width={620} height={620}><ColorArtboard theme="light" /></DCArtboard>
          <DCArtboard id="col-d"   label="Color · dark"             width={620} height={620}><ColorArtboard theme="dark" /></DCArtboard>
          <DCArtboard id="type"    label="Typography"               width={620} height={620}><TypeArtboard /></DCArtboard>
          <DCArtboard id="space"   label="Spacing · radius · shadow" width={620} height={620}><SpacingArtboard /></DCArtboard>
          <DCArtboard id="icons"   label="Iconography"              width={620} height={620}><IconsArtboard /></DCArtboard>
        </DCSection>

        {/* ───── Components ───── */}
        <DCSection id="components" title="Components" subtitle="Buttons, inputs, status, role labels, cells">
          <DCArtboard id="btns"   label="Buttons · inputs"          width={620} height={500}><ButtonsArtboard /></DCArtboard>
          <DCArtboard id="badges" label="Status · roles · cells"    width={620} height={680}><BadgesArtboard /></DCArtboard>
        </DCSection>

        {/* ───── App shell ───── */}
        <DCSection id="shell" title="App shell" subtitle="Sidebar · topbar · sub-nav, plus mobile bottom nav. Role tweak swaps the nav.">
          <DCArtboard id="shell-l" label="Desktop · light"   width={1200} height={760}><AppShellArtboard theme="light" role={t.role} /></DCArtboard>
          <DCArtboard id="shell-d" label="Desktop · dark"    width={1200} height={760}><AppShellArtboard theme="dark"  role={t.role} /></DCArtboard>
          <DCArtboard id="shell-m" label="Mobile · bottom nav" width={375} height={812}><MobileSchedule theme="light" /></DCArtboard>
        </DCSection>

        {/* ───── Schedule views ───── */}
        <DCSection id="schedule" title="Schedule · employee" subtitle="Three sub-views that share header + nav. Roster is the default.">
          <DCArtboard id="roster" label="Roster · staff × week"     width={1280} height={820}><RosterArtboard theme="light" role={t.role} /></DCArtboard>
          <DCArtboard id="month"  label="Month · calendar"          width={1280} height={820}><MonthArtboard  theme="light" /></DCArtboard>
          <DCArtboard id="matrix" label="Matrix · provider × week"  width={1280} height={820}><MatrixArtboard theme="light" /></DCArtboard>
          <DCArtboard id="roster-d" label="Roster · dark"           width={1280} height={820}><RosterArtboard theme="dark" role={t.role} /></DCArtboard>
        </DCSection>

        {/* ───── Swap board ───── */}
        <DCSection id="swap-board" title="Swap board" subtitle="Marketplace of open shifts. Cards surface urgency, role &amp; proposal count.">
          <DCArtboard id="swap-l" label="Swap board"              width={1280} height={820}><SwapBoardArtboard theme="light" role={t.role} /></DCArtboard>
          <DCArtboard id="swap-d" label="Swap board · dark"       width={1280} height={820}><SwapBoardArtboard theme="dark"  role={t.role} /></DCArtboard>
        </DCSection>

        {/* ───── Swap detail / propose ───── */}
        <DCSection id="propose" title="Propose a swap" subtitle="Split layout: their offer left, your eligible shifts right. 3-step flow.">
          <DCArtboard id="step-1" label="1 · Browse"     width={1280} height={820}><ProposeArtboard theme="light" step="browse" /></DCArtboard>
          <DCArtboard id="step-2" label="2 · Review"     width={1280} height={820}><ProposeArtboard theme="light" step="review" /></DCArtboard>
          <DCArtboard id="step-3" label="3 · Confirm"    width={1280} height={820}><ProposeArtboard theme="light" step="confirm" /></DCArtboard>
        </DCSection>

        {/* ───── My swaps ───── */}
        <DCSection id="my-swaps" title="My swaps" subtitle="Posts I've made, proposals I've sent &amp; received.">
          <DCArtboard id="my" label="My swaps" width={1280} height={760}><MySwapsArtboard theme="light" /></DCArtboard>
        </DCSection>

        {/* ───── Admin ───── */}
        <DCSection id="admin" title="Admin" subtitle="Hub with live KPIs · editor with inline pickers · approvals queue · balance.">
          <DCArtboard id="hub"      label="Admin hub · live KPIs" width={1280} height={920}><AdminHubArtboard theme="light" role={t.role === "employee" ? "manager" : t.role} /></DCArtboard>
          <DCArtboard id="editor"   label="Schedule editor"        width={1280} height={860}><AdminEditorArtboard theme="light" role={t.role === "employee" ? "manager" : t.role} /></DCArtboard>
          <DCArtboard id="approvals" label="Swap approvals"        width={1280} height={780}><AdminApprovalsArtboard theme="light" role={t.role === "employee" ? "manager" : t.role} /></DCArtboard>
          <DCArtboard id="balance"  label="Balance report"         width={1280} height={760}><BalanceArtboard theme="light" /></DCArtboard>
        </DCSection>

        {/* ───── Mobile ───── */}
        <DCSection id="mobile" title="Mobile · employee" subtitle="375 × 812 — schedule, swap board, swap detail, inbox.">
          <DCArtboard id="m-sched"   label="Schedule" width={375} height={812}><MobileSchedule    theme="light" /></DCArtboard>
          <DCArtboard id="m-board"   label="Swap board" width={375} height={812}><MobileSwapBoard  theme="light" /></DCArtboard>
          <DCArtboard id="m-detail"  label="Swap detail / propose" width={375} height={812}><MobileSwapDetail theme="light" /></DCArtboard>
          <DCArtboard id="m-inbox"   label="Inbox · my swaps" width={375} height={812}><MobileMySwaps theme="light" /></DCArtboard>
          <DCArtboard id="m-sched-d" label="Schedule · dark" width={375} height={812}><MobileSchedule theme="dark" /></DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakColor
          label="Accent color"
          value={t.accent}
          options={ACCENT_OPTIONS}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["comfortable", "compact"]}
          onChange={(v) => setTweak("density", v)}
        />

        <TweakSection label="Viewer role" />
        <TweakSelect
          label="Role"
          value={t.role}
          options={["employee", "manager", "developer"]}
          onChange={(v) => setTweak("role", v)}
        />

        <TweakSection label="Schedule view" />
        <TweakRadio
          label="Sub-view"
          value={t.scheduleView}
          options={["roster", "month", "matrix"]}
          onChange={(v) => setTweak("scheduleView", v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
