// Shared sample data — multi-specialty clinic
// Loaded as a plain script so all the JSX files can read window.NLS_DATA.

(function () {
  const providers = [
    { id: "pat", name: "Dr. Nadia Patel", short: "Patel",   specialty: "Family Med",    color: "#2563eb", initials: "NP" },
    { id: "oka", name: "Dr. Marcus Okafor", short: "Okafor", specialty: "Cardiology",    color: "#dc2626", initials: "MO" },
    { id: "rom", name: "Dr. Ines Romero", short: "Romero",  specialty: "Dermatology",   color: "#db2777", initials: "IR" },
    { id: "che", name: "Dr. Wei Chen", short: "Chen",       specialty: "Pediatrics",    color: "#0d9488", initials: "WC" },
    { id: "rey", name: "Dr. Sam Reyes", short: "Reyes",     specialty: "Internal Med",  color: "#7c3aed", initials: "SR" },
    { id: "hal", name: "Dr. Jordan Hale", short: "Hale",    specialty: "Endocrinology", color: "#b45309", initials: "JH" },
    { id: "boa", name: "Dr. Lin Boateng", short: "Boateng", specialty: "OB/GYN",        color: "#0369a1", initials: "LB" },
  ];

  const staff = [
    { id: "maya",    name: "Maya Lin",        first: "Maya",    role: "MA",     initials: "ML", hue: "#7c3aed" },
    { id: "devon",   name: "Devon Brooks",    first: "Devon",   role: "RN",     initials: "DB", hue: "#0d9488" },
    { id: "priya",   name: "Priya Shah",      first: "Priya",   role: "Scribe", initials: "PS", hue: "#b45309" },
    { id: "camila",  name: "Camila Ortiz",    first: "Camila",  role: "MA",     initials: "CO", hue: "#7c3aed" },
    { id: "theo",    name: "Theo Walsh",      first: "Theo",    role: "RN",     initials: "TW", hue: "#0d9488" },
    { id: "aisha",   name: "Aisha Bello",     first: "Aisha",   role: "MA",     initials: "AB", hue: "#7c3aed" },
    { id: "ren",     name: "Ren Tanaka",      first: "Ren",     role: "Scribe", initials: "RT", hue: "#b45309" },
    { id: "sasha",   name: "Sasha Kim",       first: "Sasha",   role: "RN",     initials: "SK", hue: "#0d9488" },
    { id: "nora",    name: "Nora Albright",   first: "Nora",    role: "MA",     initials: "NA", hue: "#7c3aed" },
    { id: "elias",   name: "Elias Foster",    first: "Elias",   role: "Front",  initials: "EF", hue: "#db2777" },
  ];

  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const dates = ["Mar 17", "Mar 18", "Mar 19", "Mar 20", "Mar 21"];

  // Roster matrix — staff × weekday → providerId (or null = off)
  // Hand-curated to feel realistic (rotations, some gaps, some pending)
  const roster = {
    maya:   ["pat", "pat", null, "oka", "oka"],
    devon:  ["oka", "rey", "rey", "pat", "pat"],
    priya:  ["rom", "rom", "rom", null, "rom"],
    camila: ["che", "che", "che", "che", "che"],
    theo:   ["hal", "hal", "pat", "rey", null],
    aisha:  [null, "oka", "oka", "hal", "hal"],
    ren:    ["rey", null, "boa", "boa", "boa"],
    sasha:  ["pat", "che", "che", "rom", "rom"],
    nora:   ["boa", "boa", "hal", null, "pat"],
    elias:  ["—", "—", "—", "—", "—"], // front-desk, not paired
  };

  // Swaps marked on the roster (highlighted on a couple cells)
  const swaps = {
    "maya/Wed": "pending",       // posted, has proposals
    "theo/Fri": "open",          // open swap post
    "aisha/Mon": "open",
    "priya/Thu": "open",
    "ren/Tue": "approved",       // swap approved
  };

  // Swap board posts (open posts from staff)
  const posts = [
    {
      id: "p-1042",
      author: "Theo Walsh", role: "RN", initials: "TW",
      date: "Fri, Mar 21", provider: "Dr. Hale", specialty: "Endocrinology",
      shift: "Full day · 8am – 5pm",
      reason: "Family obligation — kid's recital.",
      posted: "2h ago", expires: "in 18h", proposals: 3,
      status: "has-proposals", urgent: true,
    },
    {
      id: "p-1041",
      author: "Aisha Bello", role: "MA", initials: "AB",
      date: "Mon, Mar 17", provider: "Dr. Okafor", specialty: "Cardiology",
      shift: "Half day · AM",
      reason: "DMV appointment, can't reschedule.",
      posted: "5h ago", expires: "in 2d",  proposals: 1,
      status: "has-proposals",
    },
    {
      id: "p-1040",
      author: "Priya Shah", role: "Scribe", initials: "PS",
      date: "Thu, Mar 20", provider: "Dr. Romero", specialty: "Dermatology",
      shift: "Full day · 9am – 6pm",
      reason: "Specialist visit.",
      posted: "1d ago", expires: "in 1d", proposals: 0,
      status: "open",
    },
    {
      id: "p-1039",
      author: "Camila Ortiz", role: "MA", initials: "CO",
      date: "Wed, Mar 26", provider: "Dr. Chen", specialty: "Pediatrics",
      shift: "Full day · 8am – 5pm",
      reason: "Out of town for a wedding.",
      posted: "2d ago", expires: "in 5d", proposals: 0,
      status: "open",
    },
    {
      id: "p-1038",
      author: "Nora Albright", role: "MA", initials: "NA",
      date: "Thu, Mar 20", provider: "Dr. Boateng", specialty: "OB/GYN",
      shift: "Full day · 8am – 5pm",
      reason: "Childcare fell through.",
      posted: "6h ago", expires: "in 14h", proposals: 2,
      status: "has-proposals", urgent: true,
    },
    {
      id: "p-1037",
      author: "Ren Tanaka", role: "Scribe", initials: "RT",
      date: "Wed, Mar 19", provider: "Dr. Boateng", specialty: "OB/GYN",
      shift: "Half day · PM",
      reason: "Doctor's appointment.",
      posted: "3d ago", expires: "expired", proposals: 0,
      status: "expired",
    },
  ];

  // For "my swaps"
  const mySwaps = {
    posted: [
      { id: "p-1041", date: "Mon, Mar 17", provider: "Dr. Okafor", proposals: 1, status: "has-proposals" },
      { id: "p-1029", date: "Tue, Mar 25", provider: "Dr. Patel",   proposals: 0, status: "open" },
    ],
    proposalsMade: [
      { id: "pr-882", target: "Theo Walsh",   targetDate: "Fri, Mar 21", offered: "Thu, Mar 20 · Dr. Hale",     status: "pending" },
      { id: "pr-879", target: "Nora Albright", targetDate: "Thu, Mar 20", offered: "Wed, Mar 19 · Dr. Boateng",  status: "declined" },
    ],
    proposalsReceived: [
      { id: "pr-885", from: "Devon Brooks", forDate: "Mon, Mar 17", offered: "Tue, Mar 18 · Dr. Reyes", status: "pending" },
    ],
  };

  // Pending swap approvals for admin
  const pendingApprovals = [
    { id: "ap-201", a: "Theo Walsh",  aDate: "Fri, Mar 21", aProv: "Dr. Hale",   b: "Maya Lin",      bDate: "Thu, Mar 20", bProv: "Dr. Patel",   submitted: "2h ago",  conflict: false },
    { id: "ap-200", a: "Aisha Bello", aDate: "Mon, Mar 17", aProv: "Dr. Okafor", b: "Sasha Kim",     bDate: "Tue, Mar 18", bProv: "Dr. Chen",    submitted: "4h ago",  conflict: true,  conflictNote: "Sasha already covers Dr. Chen Mon — would double-book." },
    { id: "ap-199", a: "Nora Albright", aDate: "Thu, Mar 20", aProv: "Dr. Boateng", b: "Ren Tanaka", bDate: "Fri, Mar 21", bProv: "Dr. Boateng", submitted: "6h ago",  conflict: false },
  ];

  // Balance: provider → ratio (paired vs unpaired this week)
  const balance = [
    { prov: "Dr. Patel",   ratio: "5 / 5", status: "ok",       weeks: [5, 5, 4, 5, 5] },
    { prov: "Dr. Okafor",  ratio: "4 / 5", status: "warn",     weeks: [5, 4, 5, 4, 4], note: "Mon unstaffed" },
    { prov: "Dr. Romero",  ratio: "4 / 5", status: "warn",     weeks: [5, 5, 5, 4, 4], note: "Thu unstaffed" },
    { prov: "Dr. Chen",    ratio: "5 / 5", status: "ok",       weeks: [5, 5, 5, 5, 5] },
    { prov: "Dr. Reyes",   ratio: "3 / 5", status: "alert",    weeks: [3, 4, 3, 5, 3], note: "2 days unstaffed" },
    { prov: "Dr. Hale",    ratio: "4 / 5", status: "warn",     weeks: [5, 4, 4, 5, 4], note: "Fri pending swap" },
    { prov: "Dr. Boateng", ratio: "5 / 5", status: "ok",       weeks: [4, 5, 5, 5, 5] },
  ];

  window.NLS_DATA = {
    providers, staff, days, dates, roster, swaps, posts,
    mySwaps, pendingApprovals, balance,
  };

  // helpers
  window.NLS_helpers = {
    providerById: (id) => providers.find((p) => p.id === id),
    staffById: (id) => staff.find((s) => s.id === id),
    roleColor: (role) => ({
      RN: "var(--nls-role-rn)",
      MA: "var(--nls-role-ma)",
      Scribe: "var(--nls-role-scribe)",
      Front: "var(--nls-role-front)",
    }[role] || "var(--nls-text-muted)"),
    roleSoft: (role) => ({
      RN: "var(--nls-role-rn-soft)",
      MA: "var(--nls-role-ma-soft)",
      Scribe: "var(--nls-role-scribe-soft)",
      Front: "var(--nls-role-front-soft)",
    }[role] || "var(--nls-neutral-soft)"),
  };
})();
