// Mobile employee screens — schedule (week), swap board, swap detail, my-swaps.

const { posts: MPOSTS, providers: MPROVS, days: MDAYS, dates: MDATES, roster: MROSTER, swaps: MSWAPS, mySwaps: MMY } = window.NLS_DATA;
const { providerById: mProvById } = window.NLS_helpers;

// ── Mobile schedule (week + today highlight) ──────────────────────
const MobileSchedule = ({ theme = "light" }) => {
  // Maya's week
  const mine = MROSTER.maya;
  return (
    <MobileFrame theme={theme}>
      <MobileHeader
        title="My week"
        sub="Mar 17 – 21 · Tap a day for details"
        leading={<button style={mobileIconBtn}><Icon name="menu" size={20} /></button>}
        trailing={<button style={mobileIconBtn}><Icon name="bell" size={20} /></button>}
      />

      {/* week tabs */}
      <div style={{ display: "flex", padding: "8px 12px", gap: 6, borderBottom: "1px solid var(--nls-divider)" }}>
        {MDAYS.map((d, i) => {
          const today = i === 1;
          const active = i === 1;
          return (
            <div key={d} style={{
              flex: 1, padding: "8px 0", borderRadius: 10,
              display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
              background: active ? "var(--nls-accent)" : "transparent",
              color: active ? "#fff" : "var(--nls-text-muted)",
              cursor: "pointer",
            }}>
              <span style={{ fontSize: 10, fontWeight: 500, opacity: 0.8, textTransform: "uppercase", letterSpacing: ".06em" }}>{d.slice(0, 1)}</span>
              <span className="nls-num" style={{ fontSize: 17, fontWeight: 600 }}>{MDATES[i].split(" ")[1]}</span>
              {!active && mine[i] && mine[i] !== null && <span style={{ width: 4, height: 4, borderRadius: 2, background: "var(--nls-accent)" }} />}
            </div>
          );
        })}
      </div>

      <main style={{ flex: 1, padding: "20px 16px", overflowY: "auto", background: "var(--nls-bg)" }}>
        {/* Today big card */}
        <div style={{ fontSize: 11, color: "var(--nls-text-subtle)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>Today</div>
        <Card padded={false} style={{ padding: 18, marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4 }}>
            <span className="nls-num" style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", color: "var(--nls-text-strong)" }}>Tue, Mar 18</span>
          </div>
          <div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 10, padding: 12, borderRadius: 10, background: "var(--nls-accent-soft)", border: "1px solid var(--nls-accent)" }}>
            <span style={{ width: 6, height: 38, borderRadius: 3, background: "#2563eb", flex: "0 0 6px" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: "var(--nls-text-strong)" }}>Dr. Patel</div>
              <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)" }}>Family Med · Room 4</div>
            </div>
            <span className="nls-mono" style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>8a – 5p</span>
          </div>
          <div style={{ marginTop: 12, display: "flex", alignItems: "center", gap: 10 }}>
            <AvatarStack people={[
              { initials: "DB", hue: "var(--nls-role-rn)" },
              { initials: "SK", hue: "var(--nls-role-rn)" },
              { initials: "EF", hue: "var(--nls-role-front)" },
            ]} max={3} size={22} />
            <span style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>You'll work with Devon, Sasha &amp; Elias</span>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
            <Button variant="primary" size="md" icon="swap" full>Swap this day</Button>
            <Button variant="secondary" size="md" icon="users">Team</Button>
          </div>
        </Card>

        {/* The rest of the week */}
        <div style={{ fontSize: 11, color: "var(--nls-text-subtle)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>Rest of the week</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[2, 3, 4].map((i) => {
            const provId = mine[i];
            const swKey = `maya/${MDAYS[i]}`;
            const sw = MSWAPS[swKey];
            const p = provId && provId !== "—" ? mProvById(provId) : null;
            return (
              <div key={i} style={{
                padding: 14, background: "var(--nls-surface)",
                border: `1px solid ${sw === "pending" ? "var(--nls-accent)" : "var(--nls-border)"}`,
                borderRadius: 10,
                display: "flex", alignItems: "center", gap: 12,
              }}>
                <div style={{ minWidth: 48 }}>
                  <div style={{ fontSize: 10, fontWeight: 600, color: "var(--nls-text-subtle)", letterSpacing: ".08em", textTransform: "uppercase" }}>{MDAYS[i]}</div>
                  <div className="nls-num" style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)" }}>{MDATES[i].split(" ")[1]}</div>
                </div>
                <span style={{ width: 4, height: 36, borderRadius: 2, background: p ? p.color : "var(--nls-border-strong)", flex: "0 0 4px" }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  {provId === null ? (
                    <div style={{ fontSize: 14, color: "var(--nls-text-subtle)", fontStyle: "italic" }}>Day off</div>
                  ) : (
                    <>
                      <div style={{ fontSize: 14, fontWeight: 500, color: "var(--nls-text-strong)" }}>{p.name}</div>
                      <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>{p.specialty}</div>
                    </>
                  )}
                </div>
                {sw === "pending" && <Badge tone="accent" dot size="sm">Proposals</Badge>}
                {sw === "open" && <Badge tone="warning" dot size="sm">Posted</Badge>}
                <Icon name="chevronRight" size={14} color="var(--nls-text-subtle)" />
              </div>
            );
          })}
        </div>
      </main>

      <BottomNav active="schedule" />
    </MobileFrame>
  );
};

// ── Mobile swap board ─────────────────────────────────────────────
const MobileSwapBoard = ({ theme = "light" }) => (
  <MobileFrame theme={theme}>
    <MobileHeader
      title="Swap board"
      sub="6 open · 2 expiring soon"
      leading={<button style={mobileIconBtn}><Icon name="filter" size={20} /></button>}
      trailing={<button style={mobileIconBtn}><Icon name="search" size={20} /></button>}
    />

    {/* filter pills */}
    <div style={{ display: "flex", gap: 6, padding: "10px 16px 8px", overflowX: "auto", borderBottom: "1px solid var(--nls-divider)" }}>
      {[
        { label: "All", count: 6, active: true },
        { label: "Match me", count: 4, tone: "accent" },
        { label: "Urgent", count: 2, tone: "warning" },
        { label: "RN" }, { label: "MA" }, { label: "Scribe" },
      ].map((t, i) => (
        <div key={i} style={{
          padding: "6px 12px", borderRadius: 999,
          background: t.active ? "var(--nls-text-strong)" : "var(--nls-surface)",
          color: t.active ? "var(--nls-bg)" : "var(--nls-text-muted)",
          border: t.active ? "none" : "1px solid var(--nls-border-strong)",
          fontSize: 12, fontWeight: 500, whiteSpace: "nowrap",
          display: "inline-flex", alignItems: "center", gap: 5,
        }}>
          {t.label}{t.count != null && <span style={{
            fontSize: 10, fontWeight: 600, padding: "0 5px",
            background: t.active ? "rgba(255,255,255,.18)" : "var(--nls-neutral-soft)",
            color: t.active ? "var(--nls-bg)" : "var(--nls-text-subtle)",
            borderRadius: 999,
          }}>{t.count}</span>}
        </div>
      ))}
    </div>

    <main style={{ flex: 1, padding: 12, overflowY: "auto", background: "var(--nls-bg)" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {MPOSTS.slice(0, 4).map((p) => {
          const roleKey = p.role === "Front" ? "front" : p.role.toLowerCase();
          return (
            <Card key={p.id} padded={false} style={{ padding: 14, position: "relative", overflow: "hidden" }}>
              {p.urgent && (
                <span style={{
                  position: "absolute", top: 0, right: 0,
                  padding: "3px 9px", background: "var(--nls-warning)", color: "#fff",
                  fontSize: 9.5, fontWeight: 600, letterSpacing: ".06em", textTransform: "uppercase",
                  borderBottomLeftRadius: 8,
                }}>Expires {p.expires}</span>
              )}
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <Avatar initials={p.initials} hue={`var(--nls-role-${roleKey})`} size={28} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)", display: "flex", alignItems: "center", gap: 6 }}>
                    {p.author}
                    <Badge tone={roleKey} size="sm" dot>{p.role}</Badge>
                  </div>
                  <div style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>{p.posted}</div>
                </div>
              </div>
              <div style={{ padding: 10, background: "var(--nls-bg-tint)", borderRadius: 8, marginBottom: 8 }}>
                <div className="nls-num" style={{ fontSize: 16, fontWeight: 600, color: "var(--nls-text-strong)" }}>{p.date}</div>
                <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{p.provider} · <span className="nls-mono" style={{ fontSize: 11 }}>{p.shift.split(" · ")[1]}</span></div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", gap: 6 }}>
                  <StatusChip status={p.status} size="sm" />
                  {p.proposals > 0 && <span style={{ fontSize: 11, color: "var(--nls-text-muted)" }}>{p.proposals} proposal{p.proposals > 1 ? "s" : ""}</span>}
                </div>
                <Button variant="primary" size="sm">Propose</Button>
              </div>
            </Card>
          );
        })}
      </div>
    </main>

    <BottomNav active="swap-board" />
  </MobileFrame>
);

// ── Mobile swap detail / propose flow ─────────────────────────────
const MobileSwapDetail = ({ theme = "light" }) => {
  const post = MPOSTS[0];
  return (
    <MobileFrame theme={theme}>
      <MobileHeader
        title={`#${post.id}`}
        sub="Theo Walsh's swap"
        leading={<button style={mobileIconBtn}><Icon name="chevronLeft" size={22} /></button>}
        trailing={<button style={mobileIconBtn}><Icon name="moreH" size={20} /></button>}
      />

      <main style={{ flex: 1, overflowY: "auto", background: "var(--nls-bg)", padding: "16px 16px 24px" }}>
        {/* Their offer big block */}
        <div style={{
          padding: 18, background: "var(--nls-surface)",
          border: "1px solid var(--nls-border)", borderRadius: 14, marginBottom: 14,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
            <Avatar initials="TW" hue="var(--nls-role-rn)" size={36} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: "var(--nls-text-strong)" }}>Theo Walsh</div>
              <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>RN · 4y tenure</div>
            </div>
            <div style={{ flex: 1 }} />
            <Badge tone="warning" dot size="sm">18h left</Badge>
          </div>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--nls-text-subtle)", textTransform: "uppercase", letterSpacing: ".08em" }}>Wants to drop</div>
          <div className="nls-num" style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", color: "var(--nls-text-strong)", marginTop: 4 }}>Fri, Mar 21</div>
          <div style={{ marginTop: 10, padding: 10, borderRadius: 8, background: "var(--nls-bg-tint)", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ width: 5, height: 30, borderRadius: 2, background: "#b45309", flex: "0 0 5px" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: 500, color: "var(--nls-text-strong)" }}>Dr. Hale</div>
              <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>Endocrinology</div>
            </div>
            <span className="nls-mono" style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>8a – 5p</span>
          </div>
          <div style={{ marginTop: 12, fontSize: 12.5, color: "var(--nls-text-muted)", lineHeight: 1.55, fontStyle: "italic" }}>
            "Family obligation — kid's recital. Owe you one!"
          </div>
        </div>

        {/* Pick offer */}
        <div style={{ fontSize: 11, fontWeight: 600, color: "var(--nls-text-subtle)", textTransform: "uppercase", letterSpacing: ".08em", padding: "0 4px 8px" }}>
          Pick a shift to offer
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[
            { date: "Thu, Mar 20", prov: "Dr. Patel",  spec: "Family Med",    match: 92, sel: true,  color: "#2563eb" },
            { date: "Wed, Mar 19", prov: "Dr. Okafor", spec: "Cardiology",    match: 78, color: "#dc2626" },
            { date: "Mon, Mar 17", prov: "Dr. Patel",  spec: "Family Med",    match: 64, color: "#2563eb" },
          ].map((m, i) => (
            <div key={i} style={{
              padding: 12, borderRadius: 10,
              border: m.sel ? "2px solid var(--nls-accent)" : "1px solid var(--nls-border)",
              background: m.sel ? "var(--nls-accent-soft)" : "var(--nls-surface)",
              display: "flex", alignItems: "center", gap: 10,
            }}>
              <span style={{ width: 4, height: 32, borderRadius: 2, background: m.color, flex: "0 0 4px" }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="nls-num" style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)" }}>{m.date}</div>
                <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>{m.prov} · {m.spec}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="nls-num" style={{ fontSize: 16, fontWeight: 600, color: m.match >= 80 ? "var(--nls-success)" : "var(--nls-warning)", letterSpacing: "-0.02em" }}>
                  {m.match}<span style={{ fontSize: 10, color: "var(--nls-text-subtle)" }}>%</span>
                </div>
                <div style={{ fontSize: 9, color: "var(--nls-text-subtle)", fontWeight: 500, textTransform: "uppercase", letterSpacing: ".06em" }}>match</div>
              </div>
              {m.sel && (
                <span style={{
                  width: 22, height: 22, borderRadius: 11, background: "var(--nls-accent)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}><Icon name="check" size={12} color="#fff" /></span>
              )}
            </div>
          ))}
        </div>
      </main>

      <div style={{ padding: "12px 16px 28px", borderTop: "1px solid var(--nls-divider)", background: "var(--nls-surface)", display: "flex", gap: 10 }}>
        <Button variant="secondary" size="lg">Cancel</Button>
        <Button variant="primary" size="lg" iconAfter="arrowRight" full>Send proposal</Button>
      </div>
    </MobileFrame>
  );
};

// ── Mobile my-swaps ───────────────────────────────────────────────
const MobileMySwaps = ({ theme = "light" }) => (
  <MobileFrame theme={theme}>
    <MobileHeader
      title="Inbox"
      sub="Your posts &amp; proposals"
      leading={<button style={mobileIconBtn}><Icon name="filter" size={20} /></button>}
      trailing={<button style={mobileIconBtn}><Icon name="plus" size={22} /></button>}
    />

    {/* segmented tabs */}
    <div style={{ padding: "10px 16px 8px", display: "flex", gap: 6 }}>
      {[
        { label: "Received", count: 1, active: true },
        { label: "Sent", count: 2 },
        { label: "Posted", count: 2 },
      ].map((t) => (
        <div key={t.label} style={{
          flex: 1, padding: "8px 0", borderRadius: 8,
          textAlign: "center", fontSize: 13, fontWeight: 500,
          background: t.active ? "var(--nls-surface)" : "transparent",
          color: t.active ? "var(--nls-text-strong)" : "var(--nls-text-muted)",
          border: t.active ? "1px solid var(--nls-border-strong)" : "1px solid transparent",
          boxShadow: t.active ? "var(--nls-shadow-1)" : "none",
        }}>
          {t.label}{t.count > 0 && <span style={{ marginLeft: 6, fontSize: 11, color: t.active ? "var(--nls-accent)" : "var(--nls-text-subtle)", fontWeight: 600 }}>{t.count}</span>}
        </div>
      ))}
    </div>

    <main style={{ flex: 1, overflowY: "auto", padding: "8px 16px 16px", background: "var(--nls-bg)" }}>
      {/* Received highlight */}
      <Card padded={false} style={{ padding: 16, borderColor: "var(--nls-accent)", boxShadow: "var(--nls-shadow-2)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <Avatar initials="DB" hue="var(--nls-role-rn)" size={32} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>Devon Brooks</div>
            <div style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>RN · proposed 1h ago</div>
          </div>
          <Badge tone="accent" dot size="sm">New</Badge>
        </div>
        <div style={{ padding: 10, background: "var(--nls-bg-tint)", borderRadius: 8, fontSize: 12.5, color: "var(--nls-text)", marginBottom: 12 }}>
          For your <span className="nls-num" style={{ fontWeight: 600 }}>Mon, Mar 17</span> · Dr. Okafor
          <div style={{ marginTop: 6, paddingTop: 6, borderTop: "1px solid var(--nls-divider)", color: "var(--nls-text-muted)" }}>
            Offers: <span className="nls-num" style={{ color: "var(--nls-text)", fontWeight: 500 }}>Tue, Mar 18 · Dr. Reyes</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Button variant="primary" size="md" icon="check" full>Accept</Button>
          <Button variant="secondary" size="md">Decline</Button>
        </div>
      </Card>

      <div style={{ fontSize: 11, fontWeight: 600, color: "var(--nls-text-subtle)", textTransform: "uppercase", letterSpacing: ".08em", padding: "16px 4px 8px" }}>
        Earlier
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {[
          { who: "Theo Walsh",  date: "Fri, Mar 21", offered: "Thu, Mar 20 · Dr. Hale",   status: "pending",  icon: "arrowRight" },
          { who: "Nora Albright", date: "Thu, Mar 20", offered: "Wed, Mar 19 · Dr. Boateng", status: "declined", icon: "arrowRight" },
          { who: "—",  date: "Mon, Mar 17",  offered: "1 proposal received", status: "has-proposals", icon: "inbox" },
          { who: "—",  date: "Tue, Mar 25",  offered: "Posted · still open", status: "open",          icon: "inbox" },
        ].map((row, i) => (
          <Card key={i} padded={false} style={{ padding: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Icon name={row.icon} size={18} color="var(--nls-text-muted)" />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="nls-num" style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>{row.date}</div>
                <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>
                  {row.who !== "—" ? `To ${row.who} · ${row.offered}` : row.offered}
                </div>
              </div>
              <StatusChip status={row.status} size="sm" />
            </div>
          </Card>
        ))}
      </div>
    </main>

    <BottomNav active="my-swaps" />
  </MobileFrame>
);

const mobileIconBtn = {
  width: 36, height: 36, border: "none", background: "transparent",
  borderRadius: 8, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
  color: "var(--nls-text)",
};

Object.assign(window, { MobileSchedule, MobileSwapBoard, MobileSwapDetail, MobileMySwaps });
