// Primitives — buttons, badges, avatars, icons, status chips.
// Pure functional components, no state. All visual via tokens.css.

const { useState } = React;

// ── icons (Notion-style, clean line art, 1.5px stroke) ────────────
const Icon = ({ name, size = 16, color = "currentColor", strokeWidth = 1.6, style }) => {
  const paths = {
    calendar: <>
      <rect x="3" y="4.5" width="14" height="13" rx="1.8" />
      <path d="M3 8h14M7 2.5v4M13 2.5v4" />
    </>,
    grid: <>
      <rect x="3" y="3" width="6" height="6" rx="1" />
      <rect x="11" y="3" width="6" height="6" rx="1" />
      <rect x="3" y="11" width="6" height="6" rx="1" />
      <rect x="11" y="11" width="6" height="6" rx="1" />
    </>,
    table: <>
      <rect x="3" y="4" width="14" height="12" rx="1.6" />
      <path d="M3 8.5h14M3 12.5h14M8 4v12" />
    </>,
    swap: <>
      <path d="M4 7h11M12 4l3 3-3 3" />
      <path d="M16 13H5M8 16l-3-3 3-3" />
    </>,
    inbox: <>
      <path d="M3 11l1.5-5A2 2 0 0 1 6.4 4.5h7.2a2 2 0 0 1 1.9 1.5L17 11v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 3 15.5V11Z" />
      <path d="M3 11h4l1 2h4l1-2h4" />
    </>,
    user: <>
      <circle cx="10" cy="7.5" r="3" />
      <path d="M4 16.5c.8-2.8 3-4 6-4s5.2 1.2 6 4" />
    </>,
    users: <>
      <circle cx="8" cy="7" r="2.6" />
      <path d="M3 16c.6-2.4 2.5-3.5 5-3.5s4.4 1.1 5 3.5" />
      <circle cx="14.5" cy="6.5" r="2.2" />
      <path d="M13 12.7c2.5.2 4 1.4 4.5 3.3" />
    </>,
    shield: <>
      <path d="M10 2.5l6 2.2v5.4c0 3.4-2.5 6.4-6 7.4-3.5-1-6-4-6-7.4V4.7l6-2.2Z" />
    </>,
    settings: <>
      <circle cx="10" cy="10" r="2.4" />
      <path d="M10 1.8v2.6M10 15.6v2.6M3.7 3.7l1.8 1.8M14.5 14.5l1.8 1.8M1.8 10h2.6M15.6 10h2.6M3.7 16.3l1.8-1.8M14.5 5.5l1.8-1.8" />
    </>,
    plus: <>
      <path d="M10 4v12M4 10h12" />
    </>,
    chevronDown: <>
      <path d="M5 8l5 5 5-5" />
    </>,
    chevronRight: <>
      <path d="M8 5l5 5-5 5" />
    </>,
    chevronLeft: <>
      <path d="M12 5l-5 5 5 5" />
    </>,
    check: <>
      <path d="M4 10.5l4 4 8-9" />
    </>,
    x: <>
      <path d="M5 5l10 10M15 5L5 15" />
    </>,
    search: <>
      <circle cx="9" cy="9" r="5" />
      <path d="M13 13l4 4" />
    </>,
    bell: <>
      <path d="M5.5 13.5V9.2A4.5 4.5 0 0 1 10 4.7a4.5 4.5 0 0 1 4.5 4.5v4.3" />
      <path d="M3.8 13.5h12.4M8.2 16.2a2 2 0 0 0 3.6 0" />
    </>,
    filter: <>
      <path d="M3 5h14M5.5 10h9M8 15h4" />
    </>,
    moreH: <>
      <circle cx="5" cy="10" r="1.2" /><circle cx="10" cy="10" r="1.2" /><circle cx="15" cy="10" r="1.2" />
    </>,
    alert: <>
      <path d="M10 2.5l8 14H2l8-14Z" />
      <path d="M10 8v3.5M10 13.6v.6" />
    </>,
    clock: <>
      <circle cx="10" cy="10" r="7" />
      <path d="M10 6v4l2.5 2" />
    </>,
    arrowRight: <>
      <path d="M4 10h12M11 5l5 5-5 5" />
    </>,
    arrowLeft: <>
      <path d="M16 10H4M9 5l-5 5 5 5" />
    </>,
    drag: <>
      <circle cx="7.5" cy="5" r="1.1" /><circle cx="12.5" cy="5" r="1.1" />
      <circle cx="7.5" cy="10" r="1.1" /><circle cx="12.5" cy="10" r="1.1" />
      <circle cx="7.5" cy="15" r="1.1" /><circle cx="12.5" cy="15" r="1.1" />
    </>,
    home: <>
      <path d="M3 9.5L10 3l7 6.5V16a1.5 1.5 0 0 1-1.5 1.5H4.5A1.5 1.5 0 0 1 3 16V9.5Z" />
      <path d="M8 17.5v-5h4v5" />
    </>,
    book: <>
      <path d="M4 4h5.5a2 2 0 0 1 2 2v11H6a2 2 0 0 1-2-2V4Z" />
      <path d="M16 4h-5.5a2 2 0 0 0-2 2v11H14a2 2 0 0 0 2-2V4Z" />
    </>,
    sun: <>
      <circle cx="10" cy="10" r="3" />
      <path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.6 4.6l1.4 1.4M14 14l1.4 1.4M4.6 15.4L6 14M14 6l1.4-1.4" />
    </>,
    moon: <>
      <path d="M15.5 12.5a6.5 6.5 0 0 1-8-8 6.5 6.5 0 1 0 8 8Z" />
    </>,
    sparkle: <>
      <path d="M10 3v4M10 13v4M3 10h4M13 10h4" strokeLinecap="round" />
      <path d="M5 5l2.5 2.5M12.5 12.5L15 15M5 15l2.5-2.5M12.5 7.5L15 5" strokeLinecap="round" opacity=".7" />
    </>,
    dot: <>
      <circle cx="10" cy="10" r="2.5" fill="currentColor" stroke="none" />
    </>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none"
         stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
         style={{ flex: "0 0 auto", ...style }}>
      {paths[name] || null}
    </svg>
  );
};

// ── Button ────────────────────────────────────────────────────────
const Button = ({ children, variant = "secondary", size = "md", icon, iconAfter, full, disabled, style, onClick }) => {
  const sizes = {
    sm: { h: 28, px: 10, fs: 12, gap: 6, ic: 14 },
    md: { h: 34, px: 12, fs: 13, gap: 7, ic: 16 },
    lg: { h: 40, px: 16, fs: 14, gap: 8, ic: 16 },
  };
  const s = sizes[size];
  const variants = {
    primary: {
      background: "var(--nls-accent)",
      color: "var(--nls-text-on-accent)",
      boxShadow: "0 1px 0 rgba(0,0,0,.05), inset 0 0 0 1px rgba(255,255,255,.08)",
      border: "1px solid transparent",
    },
    secondary: {
      background: "var(--nls-surface)",
      color: "var(--nls-text)",
      border: "1px solid var(--nls-border-strong)",
      boxShadow: "var(--nls-shadow-1)",
    },
    ghost: {
      background: "transparent",
      color: "var(--nls-text)",
      border: "1px solid transparent",
    },
    danger: {
      background: "var(--nls-surface)",
      color: "var(--nls-danger)",
      border: "1px solid var(--nls-border-strong)",
    },
    "danger-solid": {
      background: "var(--nls-danger)",
      color: "#fff",
      border: "1px solid transparent",
    },
  };
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        gap: s.gap, height: s.h, padding: `0 ${s.px}px`,
        fontSize: s.fs, fontWeight: 500, lineHeight: 1,
        borderRadius: "var(--nls-r-3)", cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        width: full ? "100%" : "auto",
        transition: "background .12s, border-color .12s, transform .06s",
        whiteSpace: "nowrap",
        ...variants[variant],
        ...style,
      }}
    >
      {icon && <Icon name={icon} size={s.ic} />}
      {children}
      {iconAfter && <Icon name={iconAfter} size={s.ic} />}
    </button>
  );
};

// ── Badge ──────────────────────────────────────────────────────────
// tone: neutral / accent / success / warning / danger / info / muted
const Badge = ({ children, tone = "neutral", solid, dot, size = "md", style }) => {
  const tones = {
    neutral: { fg: "var(--nls-text-muted)", bg: "var(--nls-neutral-soft)", bd: "var(--nls-border-strong)" },
    accent:  { fg: "var(--nls-accent)",     bg: "var(--nls-accent-soft)",  bd: "var(--nls-accent)" },
    success: { fg: "var(--nls-success)",    bg: "var(--nls-success-soft)", bd: "var(--nls-success)" },
    warning: { fg: "var(--nls-warning)",    bg: "var(--nls-warning-soft)", bd: "var(--nls-warning)" },
    danger:  { fg: "var(--nls-danger)",     bg: "var(--nls-danger-soft)",  bd: "var(--nls-danger)" },
    info:    { fg: "var(--nls-info)",       bg: "var(--nls-info-soft)",    bd: "var(--nls-info)" },
    rn:      { fg: "var(--nls-role-rn)",     bg: "var(--nls-role-rn-soft)",     bd: "var(--nls-role-rn)" },
    ma:      { fg: "var(--nls-role-ma)",     bg: "var(--nls-role-ma-soft)",     bd: "var(--nls-role-ma)" },
    scribe:  { fg: "var(--nls-role-scribe)", bg: "var(--nls-role-scribe-soft)", bd: "var(--nls-role-scribe)" },
    front:   { fg: "var(--nls-role-front)",  bg: "var(--nls-role-front-soft)",  bd: "var(--nls-role-front)" },
  };
  const t = tones[tone] || tones.neutral;
  const sizes = {
    sm: { h: 18, fs: 10, px: 6, gap: 4, dot: 5 },
    md: { h: 22, fs: 11, px: 8, gap: 5, dot: 6 },
    lg: { h: 26, fs: 12, px: 10, gap: 6, dot: 7 },
  };
  const sz = sizes[size];
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center", gap: sz.gap,
        height: sz.h, padding: `0 ${sz.px}px`,
        fontSize: sz.fs, fontWeight: 500, letterSpacing: ".01em",
        color: solid ? "#fff" : t.fg,
        background: solid ? t.fg : t.bg,
        borderRadius: "var(--nls-r-pill)",
        whiteSpace: "nowrap",
        textTransform: "none",
        ...style,
      }}
    >
      {dot && <span style={{ width: sz.dot, height: sz.dot, borderRadius: "50%", background: solid ? "#fff" : t.fg, opacity: solid ? 0.9 : 1 }} />}
      {children}
    </span>
  );
};

// ── Status chip — same as badge but with semantic mapping ─────────
const STATUS_MAP = {
  open:           { tone: "neutral", label: "Open",           dot: true },
  posted:         { tone: "neutral", label: "Posted",         dot: true },
  "has-proposals":{ tone: "accent",  label: "Has proposals",  dot: true },
  pending:        { tone: "warning", label: "Pending",        dot: true },
  approved:       { tone: "success", label: "Approved",       dot: true },
  accepted:       { tone: "success", label: "Accepted",       dot: true },
  declined:       { tone: "neutral", label: "Declined",       dot: false },
  rejected:       { tone: "danger",  label: "Rejected",       dot: false },
  expiring:       { tone: "danger",  label: "Expiring soon",  dot: true },
  expired:        { tone: "neutral", label: "Expired",        dot: false },
  draft:          { tone: "neutral", label: "Draft",          dot: false },
  ok:             { tone: "success", label: "Fully staffed",  dot: true },
  warn:           { tone: "warning", label: "Gaps",           dot: true },
  alert:          { tone: "danger",  label: "Critical",       dot: true },
};
const StatusChip = ({ status, label, size = "md", solid }) => {
  const s = STATUS_MAP[status] || STATUS_MAP.open;
  return <Badge tone={s.tone} dot={s.dot} solid={solid} size={size}>{label ?? s.label}</Badge>;
};

// ── Avatar ─────────────────────────────────────────────────────────
const Avatar = ({ initials, hue = "var(--nls-text-muted)", size = 28, ring }) => {
  const fs = Math.round(size * 0.42);
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        width: size, height: size, borderRadius: "50%",
        background: hue, color: "#fff",
        fontSize: fs, fontWeight: 600, letterSpacing: 0,
        boxShadow: ring ? "0 0 0 2px var(--nls-surface)" : "none",
        flex: "0 0 auto",
      }}
    >{initials}</span>
  );
};

// Avatar stack (with overflow +N)
const AvatarStack = ({ people, size = 24, max = 4 }) => {
  const shown = people.slice(0, max);
  const extra = people.length - max;
  return (
    <span style={{ display: "inline-flex", alignItems: "center" }}>
      {shown.map((p, i) => (
        <span key={i} style={{ marginLeft: i === 0 ? 0 : -8, boxShadow: "0 0 0 2px var(--nls-surface)", borderRadius: "50%" }}>
          <Avatar initials={p.initials} hue={p.hue} size={size} />
        </span>
      ))}
      {extra > 0 && (
        <span style={{
          marginLeft: -8, width: size, height: size, borderRadius: "50%",
          background: "var(--nls-surface-sunken)", color: "var(--nls-text-muted)",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          fontSize: Math.round(size * 0.36), fontWeight: 600,
          boxShadow: "0 0 0 2px var(--nls-surface)",
        }}>+{extra}</span>
      )}
    </span>
  );
};

// ── Card ───────────────────────────────────────────────────────────
const Card = ({ children, style, padded = true, hover, onClick }) => (
  <div
    onClick={onClick}
    style={{
      background: "var(--nls-surface)",
      border: "1px solid var(--nls-border)",
      borderRadius: "var(--nls-r-4)",
      boxShadow: "var(--nls-shadow-1)",
      padding: padded ? "var(--nls-s-5)" : 0,
      cursor: onClick ? "pointer" : "default",
      transition: "border-color .12s, box-shadow .12s",
      ...style,
    }}
  >{children}</div>
);

// ── Input ──────────────────────────────────────────────────────────
const Input = ({ icon, placeholder, value, style }) => (
  <label style={{
    display: "inline-flex", alignItems: "center", gap: 8,
    height: 34, padding: "0 10px",
    background: "var(--nls-surface)", border: "1px solid var(--nls-border-strong)",
    borderRadius: "var(--nls-r-3)", boxShadow: "var(--nls-shadow-1)",
    color: "var(--nls-text-muted)",
    fontSize: 13, ...style,
  }}>
    {icon && <Icon name={icon} size={15} />}
    <input
      defaultValue={value}
      placeholder={placeholder}
      style={{ border: "none", outline: "none", background: "transparent", flex: 1, color: "var(--nls-text)", minWidth: 0 }}
    />
  </label>
);

// ── Section header (inside artboards) ─────────────────────────────
const SectionTitle = ({ children, sub, style }) => (
  <div style={style}>
    <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>{children}</div>
    {sub && <div style={{ fontSize: 13, color: "var(--nls-text-muted)", marginTop: 2 }}>{sub}</div>}
  </div>
);

// ── Kbd ────────────────────────────────────────────────────────────
const Kbd = ({ children }) => (
  <span className="nls-mono" style={{
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    minWidth: 18, height: 18, padding: "0 5px",
    background: "var(--nls-surface)", border: "1px solid var(--nls-border-strong)",
    borderRadius: 4, fontSize: 10.5, color: "var(--nls-text-muted)",
  }}>{children}</span>
);

Object.assign(window, { Icon, Button, Badge, StatusChip, Avatar, AvatarStack, Card, Input, SectionTitle, Kbd, STATUS_MAP });
