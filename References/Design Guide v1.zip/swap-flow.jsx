// Swap board (marketplace), swap detail, propose-swap flow, my-swaps.

const { posts: POSTS, mySwaps: MY, providers: PROVS, staff: STAFF } = window.NLS_DATA;
const { roleColor, roleSoft } = window.NLS_helpers;

// ── Swap post card ────────────────────────────────────────────────
const SwapCard = ({ post, focused }) => {
  const roleKey = post.role === "Front" ? "front" : post.role.toLowerCase();
  return (
    <Card
      padded={false}
      style={{
        padding: 18,
        display: "flex", flexDirection: "column", gap: 12,
        boxShadow: focused ? "var(--nls-shadow-2)" : "var(--nls-shadow-1)",
        borderColor: focused ? "var(--nls-border-strong)" : "var(--nls-border)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {post.urgent && (
        <span style={{
          position: "absolute", top: 0, right: 0,
          padding: "4px 10px",
          background: "var(--nls-warning)", color: "#fff",
          fontSize: 10, fontWeight: 600, letterSpacing: ".06em", textTransform: "uppercase",
          borderBottomLeftRadius: 8,
        }}>Expires {post.expires}</span>
      )}
      {/* author row */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Avatar initials={post.initials} hue={`var(--nls-role-${roleKey})`} size={32} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>{post.author}</span>
            <Badge tone={roleKey} size="sm" dot>{post.role}</Badge>
          </div>
          <div style={{ fontSize: 11.5, color: "var(--nls-text-subtle)" }}>Posted {post.posted}</div>
        </div>
      </div>

      {/* shift block */}
      <div style={{
        padding: 12, borderRadius: 10,
        background: "var(--nls-bg-tint)", border: "1px solid var(--nls-divider)",
        display: "flex", flexDirection: "column", gap: 6,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11.5, color: "var(--nls-text-muted)", textTransform: "uppercase", letterSpacing: ".06em", fontWeight: 600 }}>
          <Icon name="calendar" size={12} /> Wants to swap out
        </div>
        <div style={{ fontSize: 16, fontWeight: 600, color: "var(--nls-text-strong)", letterSpacing: "-0.01em" }} className="nls-num">{post.date}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: "var(--nls-text)" }}>
          <span style={{ fontWeight: 500 }}>{post.provider}</span>
          <span style={{ color: "var(--nls-text-subtle)" }}>·</span>
          <span style={{ color: "var(--nls-text-muted)" }}>{post.specialty}</span>
        </div>
        <div className="nls-mono" style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>{post.shift}</div>
      </div>

      {post.reason && (
        <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)", lineHeight: 1.5, fontStyle: "italic" }}>
          “{post.reason}”
        </div>
      )}

      {/* footer */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginTop: 4 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <StatusChip status={post.status} size="md" />
          {post.proposals > 0 && (
            <span style={{ fontSize: 11.5, color: "var(--nls-text-muted)", display: "inline-flex", alignItems: "center", gap: 4 }}>
              <Icon name="inbox" size={12} /> {post.proposals} proposal{post.proposals > 1 ? "s" : ""}
            </span>
          )}
        </div>
        <Button variant={post.status === "expired" ? "ghost" : "secondary"} size="sm" disabled={post.status === "expired"}>
          {post.status === "expired" ? "Closed" : "Propose"}
        </Button>
      </div>
    </Card>
  );
};

// ── Swap board artboard ───────────────────────────────────────────
const SwapBoardArtboard = ({ theme = "light", role = "manager" }) => (
  <Shell theme={theme} role={role} active="swap-board" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0" }}>
      <Topbar
        title="Swap board"
        subtitle="Open shifts your teammates want to trade"
        week="Mar 17 – 21"
        hideWeek
      />
      <div style={{ padding: "16px 24px 12px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <Input placeholder="Search by name, date, provider…" icon="search" style={{ width: 280 }} />
          <Button variant="secondary" icon="filter">All roles</Button>
          <Button variant="ghost" icon="clock">Sort · Most urgent</Button>
        </div>
        <Button variant="primary" icon="plus">Post my shift</Button>
      </div>

      {/* segmented tabs over the board */}
      <div style={{ padding: "0 24px 16px", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
        {[
          { id: "all", label: "All", count: 6, active: true },
          { id: "urgent", label: "Expiring soon", count: 2, tone: "danger" },
          { id: "mine-eligible", label: "Match my schedule", count: 4, tone: "accent" },
          { id: "rn", label: "RN" },
          { id: "ma", label: "MA" },
          { id: "scribe", label: "Scribe" },
        ].map((tab) => (
          <div key={tab.id} style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "5px 11px", borderRadius: 999,
            background: tab.active ? "var(--nls-text-strong)" : "var(--nls-surface)",
            color: tab.active ? "var(--nls-bg)" : "var(--nls-text-muted)",
            border: tab.active ? "1px solid var(--nls-text-strong)" : "1px solid var(--nls-border-strong)",
            fontSize: 12, fontWeight: 500, cursor: "pointer",
          }}>
            <span>{tab.label}</span>
            {tab.count != null && (
              <span style={{
                fontSize: 10.5, fontWeight: 600,
                color: tab.active ? "var(--nls-bg)" : "var(--nls-text-subtle)",
                background: tab.active ? "rgba(255,255,255,.15)" : "var(--nls-neutral-soft)",
                borderRadius: 999, padding: "1px 6px",
              }}>{tab.count}</span>
            )}
          </div>
        ))}
      </div>

      <div style={{ padding: "0 24px 32px" }}>
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: 14,
        }}>
          {POSTS.map((p, i) => <SwapCard key={p.id} post={p} focused={i === 0} />)}
        </div>
      </div>
    </div>
  </Shell>
);

// ────────────────────────────────────────────────────────────────
// Swap detail + propose flow — split layout
// ────────────────────────────────────────────────────────────────
const ProposeArtboard = ({ theme = "light", step = "browse" }) => {
  const post = POSTS[0]; // Theo Walsh's Fri Mar 21 / Dr. Hale
  const mineEligible = [
    { id: "mt-1", date: "Thu, Mar 20", provider: "Dr. Patel",   specialty: "Family Med",    shift: "Full day · 8a – 5p", match: 92,  selected: step !== "browse" },
    { id: "mt-2", date: "Wed, Mar 19", provider: "Dr. Okafor",  specialty: "Cardiology",    shift: "Full day · 8a – 5p", match: 78 },
    { id: "mt-3", date: "Mon, Mar 17", provider: "Dr. Patel",   specialty: "Family Med",    shift: "Full day · 8a – 5p", match: 64 },
    { id: "mt-4", date: "Tue, Mar 25", provider: "Dr. Reyes",   specialty: "Internal Med",  shift: "Full day · 8a – 5p", match: 52, warn: "Different role" },
  ];
  const selected = step !== "browse" ? mineEligible[0] : null;

  return (
    <Shell theme={theme} active="swap-board" topbar={null} subnav={null}>
      <div style={{ margin: "-20px -24px 0", display: "flex", flexDirection: "column" }}>
        <Topbar
          title={`#${post.id}`}
          breadcrumbs={["Swap board", "Theo Walsh"]}
          hideWeek
          actions={<Button variant="ghost" size="sm">Cancel</Button>}
        />

        <div style={{ padding: "20px 24px 32px" }}>
          {/* Step indicator */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
            <StepDot n={1} label="Browse"  state={step === "browse" ? "current" : "done"} />
            <StepLine done />
            <StepDot n={2} label="Choose offer" state={step === "browse" ? "todo" : step === "review" ? "current" : "done"} />
            <StepLine done={step !== "browse"} />
            <StepDot n={3} label="Confirm" state={step === "confirm" ? "current" : "todo"} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
            {/* Their offer */}
            <Card padded={false} style={{ padding: 0, overflow: "hidden" }}>
              <div style={{
                padding: "10px 16px", fontSize: 11, fontWeight: 600, letterSpacing: ".08em",
                textTransform: "uppercase", color: "var(--nls-text-subtle)",
                background: "var(--nls-bg-tint)", borderBottom: "1px solid var(--nls-divider)",
                display: "flex", alignItems: "center", gap: 6,
              }}>
                <Icon name="arrowRight" size={12} /> They want to drop
              </div>
              <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <Avatar initials="TW" hue="var(--nls-role-rn)" size={36} />
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: "var(--nls-text-strong)" }}>Theo Walsh</div>
                    <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>RN · Tenured</div>
                  </div>
                </div>
                <div style={{ fontSize: 28, fontWeight: 600, color: "var(--nls-text-strong)", letterSpacing: "-0.015em" }} className="nls-num">Fri, Mar 21</div>
                <ShiftLine prov="Dr. Hale" spec="Endocrinology" hours="8:00 – 17:00" color="#b45309" />
                <div style={{ fontSize: 13, color: "var(--nls-text-muted)", lineHeight: 1.55, padding: 10, background: "var(--nls-bg-tint)", borderRadius: 8 }}>
                  <span style={{ color: "var(--nls-text-subtle)", fontSize: 11, textTransform: "uppercase", letterSpacing: ".06em", fontWeight: 600, display: "block", marginBottom: 4 }}>Note</span>
                  Family obligation — kid's recital. Owe you one!
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <Badge tone="warning" dot size="sm">Expires in 18h</Badge>
                  <Badge tone="accent" dot size="sm">3 proposals so far</Badge>
                </div>
              </div>
            </Card>

            {/* Your offer */}
            <Card padded={false} style={{ padding: 0, overflow: "hidden", borderColor: step !== "browse" ? "var(--nls-accent)" : "var(--nls-border)" }}>
              <div style={{
                padding: "10px 16px", fontSize: 11, fontWeight: 600, letterSpacing: ".08em",
                textTransform: "uppercase",
                color: step !== "browse" ? "var(--nls-accent)" : "var(--nls-text-subtle)",
                background: step !== "browse" ? "var(--nls-accent-soft)" : "var(--nls-bg-tint)",
                borderBottom: `1px solid ${step !== "browse" ? "var(--nls-accent)" : "var(--nls-divider)"}`,
                display: "flex", alignItems: "center", gap: 6, justifyContent: "space-between",
              }}>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                  <Icon name="arrowLeft" size={12} /> {selected ? "You'll take this in return" : "Pick a shift to offer"}
                </span>
                {step === "browse" && <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0, textTransform: "none", color: "var(--nls-text-subtle)" }}>{mineEligible.length} eligible</span>}
              </div>

              {selected ? (
                <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 12 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <Avatar initials="ML" hue="var(--nls-role-ma)" size={36} />
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "var(--nls-text-strong)" }}>You (Maya Lin)</div>
                      <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>MA · 2y tenure</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 28, fontWeight: 600, color: "var(--nls-text-strong)", letterSpacing: "-0.015em" }} className="nls-num">{selected.date}</div>
                  <ShiftLine prov={selected.provider} spec={selected.specialty} hours="8:00 – 17:00" color="#2563eb" />
                  <div style={{ padding: 12, background: "var(--nls-success-soft)", border: "1px solid var(--nls-success)", borderRadius: 8, display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 32, height: 32, borderRadius: 16, background: "var(--nls-success)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", flex: "0 0 32px" }}>
                      <Icon name="check" size={16} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12.5, fontWeight: 600, color: "var(--nls-success)" }}>{selected.match}% match · meets all pairing rules</div>
                      <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)", marginTop: 2 }}>Theo is qualified for Dr. Patel coverage on Thursdays.</div>
                    </div>
                  </div>
                  <textarea
                    placeholder="Add a message (optional)…"
                    defaultValue={step === "confirm" ? "Happy to swap — see you next week!" : ""}
                    style={{
                      padding: 10, borderRadius: 8,
                      border: "1px solid var(--nls-border-strong)", background: "var(--nls-surface)",
                      fontFamily: "inherit", fontSize: 13, color: "var(--nls-text)",
                      resize: "none", minHeight: 60, outline: "none",
                    }}
                  />
                </div>
              ) : (
                <div style={{ padding: "8px 12px 12px", display: "flex", flexDirection: "column", gap: 8 }}>
                  {mineEligible.map((m, i) => (
                    <div key={m.id} style={{
                      padding: 12, borderRadius: 10,
                      border: `1px solid ${i === 0 ? "var(--nls-accent)" : "var(--nls-border)"}`,
                      background: i === 0 ? "var(--nls-accent-soft)" : "var(--nls-surface)",
                      display: "flex", alignItems: "center", gap: 12, cursor: "pointer",
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)" }} className="nls-num">{m.date}</div>
                        <div style={{ fontSize: 12, color: "var(--nls-text-muted)", marginTop: 2 }}>{m.provider} · {m.specialty}</div>
                        <div className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-subtle)", marginTop: 2 }}>{m.shift}</div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontSize: 16, fontWeight: 600, color: m.match >= 80 ? "var(--nls-success)" : m.match >= 60 ? "var(--nls-warning)" : "var(--nls-text-muted)", letterSpacing: "-0.02em" }} className="nls-num">{m.match}<span style={{ fontSize: 10, color: "var(--nls-text-subtle)" }}>%</span></div>
                        <div style={{ fontSize: 10, color: "var(--nls-text-subtle)", fontWeight: 500 }}>match</div>
                      </div>
                      {m.warn && <Badge tone="warning" size="sm" dot>{m.warn}</Badge>}
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          {/* footer actions */}
          <div style={{ marginTop: 22, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 16px", background: "var(--nls-bg-tint)", borderRadius: 10, border: "1px solid var(--nls-divider)" }}>
            <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)" }}>
              {step === "browse" && <>Pick one of your eligible shifts. <Kbd>Esc</Kbd> to cancel.</>}
              {step === "review" && <>If accepted, your schedule will update automatically and a manager will be notified.</>}
              {step === "confirm" && <span style={{ color: "var(--nls-success)", fontWeight: 500 }}>✓ Proposal sent — Theo has 18h to respond.</span>}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <Button variant="ghost" size="md">{step === "confirm" ? "Back to board" : "Cancel"}</Button>
              {step === "browse" && <Button variant="primary" size="md" iconAfter="arrowRight">Review proposal</Button>}
              {step === "review" && <Button variant="primary" size="md" iconAfter="check">Send proposal</Button>}
              {step === "confirm" && <Button variant="primary" size="md">View my swaps</Button>}
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
};

const ShiftLine = ({ prov, spec, hours, color }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderTop: "1px solid var(--nls-divider)", borderBottom: "1px solid var(--nls-divider)" }}>
    <span style={{ width: 6, height: 32, borderRadius: 3, background: color, flex: "0 0 6px" }} />
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 14, fontWeight: 500, color: "var(--nls-text-strong)" }}>{prov}</div>
      <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{spec}</div>
    </div>
    <span className="nls-mono" style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{hours}</span>
  </div>
);

// step indicator pieces
const StepDot = ({ n, label, state }) => {
  const c = state === "current" ? "var(--nls-accent)" : state === "done" ? "var(--nls-success)" : "var(--nls-text-subtle)";
  const bg = state === "current" ? "var(--nls-accent)" : state === "done" ? "var(--nls-success)" : "transparent";
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 7 }}>
      <span style={{
        width: 20, height: 20, borderRadius: 10,
        background: bg,
        border: `1px solid ${c}`,
        color: state === "todo" ? c : "#fff",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        fontSize: 11, fontWeight: 600,
      }}>{state === "done" ? <Icon name="check" size={11} /> : n}</span>
      <span style={{ fontSize: 12.5, fontWeight: state === "current" ? 600 : 500, color: state === "todo" ? "var(--nls-text-subtle)" : "var(--nls-text-strong)" }}>{label}</span>
    </div>
  );
};
const StepLine = ({ done }) => (
  <span style={{ flex: "0 0 32px", height: 1, background: done ? "var(--nls-success)" : "var(--nls-border-strong)" }} />
);

// ── My swaps artboard ─────────────────────────────────────────────
const MySwapsArtboard = ({ theme = "light" }) => (
  <Shell theme={theme} active="my-swaps" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0" }}>
      <Topbar
        title="My swaps"
        subtitle="Posts you've made and proposals you've sent or received"
        hideWeek
      />

      <div style={{ padding: "20px 24px 32px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <Card padded={false}>
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--nls-divider)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>Posts I've made</div>
              <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)", marginTop: 1 }}>Shifts you've put on the board</div>
            </div>
            <Button variant="ghost" size="sm" icon="plus">New</Button>
          </div>
          <div>
            {MY.posted.map((p, i) => (
              <div key={p.id} style={{ padding: "12px 18px", borderBottom: i < MY.posted.length - 1 ? "1px solid var(--nls-divider)" : "none", display: "flex", alignItems: "center", gap: 12 }}>
                <Icon name="calendar" size={18} color="var(--nls-text-muted)" />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 500, color: "var(--nls-text-strong)" }} className="nls-num">{p.date}</div>
                  <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{p.provider} · <span className="nls-mono" style={{ fontSize: 11 }}>#{p.id}</span></div>
                </div>
                <StatusChip status={p.status} size="sm" />
                {p.proposals > 0 && (
                  <Badge tone="accent" size="sm">{p.proposals} proposal{p.proposals > 1 ? "s" : ""}</Badge>
                )}
              </div>
            ))}
          </div>
        </Card>

        <Card padded={false}>
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--nls-divider)" }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>Proposals I've sent</div>
            <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)", marginTop: 1 }}>Offers you've made on others' posts</div>
          </div>
          {MY.proposalsMade.map((p, i) => (
            <div key={p.id} style={{ padding: "12px 18px", borderBottom: "1px solid var(--nls-divider)" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 4 }}>
                <div style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>To {p.target} · {p.targetDate}</div>
                <StatusChip status={p.status} size="sm" />
              </div>
              <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>You offered: <span className="nls-num" style={{ color: "var(--nls-text)" }}>{p.offered}</span></div>
            </div>
          ))}

          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--nls-divider)", background: "var(--nls-accent-soft)" }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>Proposals I've received <Badge tone="accent" size="sm" style={{ marginLeft: 6 }}>{MY.proposalsReceived.length} new</Badge></div>
          </div>
          {MY.proposalsReceived.map((p) => (
            <div key={p.id} style={{ padding: "14px 18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <Avatar initials="DB" hue="var(--nls-role-rn)" size={28} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>{p.from}</div>
                  <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>For your <span className="nls-num">{p.forDate}</span> · offers <span className="nls-num">{p.offered}</span></div>
                </div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <Button variant="primary" size="sm" icon="check">Accept</Button>
                <Button variant="secondary" size="sm">Decline</Button>
                <Button variant="ghost" size="sm">View detail</Button>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  </Shell>
);

Object.assign(window, { SwapBoardArtboard, ProposeArtboard, MySwapsArtboard, SwapCard });
