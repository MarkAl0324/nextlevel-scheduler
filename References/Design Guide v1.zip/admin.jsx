// Admin hub, schedule editor, balance, approvals.

const { providers: APROVS, staff: ASTAFF, days: ADAYS, dates: ADATES, roster: AROSTER, pendingApprovals, balance } = window.NLS_DATA;

// ── Admin hub: tiles with live summaries ──────────────────────────
const HubTile = ({ icon, title, sub, status, stat, tone = "neutral", primaryAction }) => (
  <Card padded={false} style={{ padding: 20, display: "flex", flexDirection: "column", gap: 14, cursor: "pointer", minHeight: 170 }}>
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: tone === "accent" ? "var(--nls-accent-soft)" : tone === "warning" ? "var(--nls-warning-soft)" : tone === "danger" ? "var(--nls-danger-soft)" : "var(--nls-surface-sunken)",
        color: tone === "accent" ? "var(--nls-accent)" : tone === "warning" ? "var(--nls-warning)" : tone === "danger" ? "var(--nls-danger)" : "var(--nls-text-muted)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <Icon name={icon} size={18} />
      </div>
      {status}
    </div>
    <div>
      <div style={{ fontSize: 15, fontWeight: 600, color: "var(--nls-text-strong)", marginBottom: 3 }}>{title}</div>
      <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)", lineHeight: 1.5 }}>{sub}</div>
    </div>
    {stat && (
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: "auto" }}>
        <span style={{ fontSize: 26, fontWeight: 600, color: "var(--nls-text-strong)", letterSpacing: "-0.02em" }} className="nls-num">{stat.value}</span>
        <span style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{stat.label}</span>
      </div>
    )}
    {primaryAction && (
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 500, color: "var(--nls-accent)" }}>
          {primaryAction} <Icon name="arrowRight" size={12} />
        </span>
      </div>
    )}
  </Card>
);

const AdminHubArtboard = ({ theme = "light", role = "manager" }) => (
  <Shell theme={theme} role={role} active="admin-hub" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0" }}>
      <Topbar
        title="Admin hub"
        subtitle="Tuesday, March 18 — what needs your attention today"
        breadcrumbs={["Workspace", "Manage"]}
        hideWeek
      />

      <div style={{ padding: "20px 24px 32px" }}>
        {/* Hero KPIs strip */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12,
          marginBottom: 18,
        }}>
          {[
            { label: "Staff on shift", value: "27", sub: "of 32 scheduled", tone: "accent", trend: "+2 vs yesterday" },
            { label: "Open swaps",     value: "6",  sub: "2 expiring soon",   tone: "warning" },
            { label: "Pending approvals", value: "3", sub: "1 has a conflict", tone: "danger" },
            { label: "Unstaffed cells", value: "2", sub: "Dr. Reyes Tue, Thu", tone: "danger" },
          ].map((k) => (
            <Card key={k.label} padded={false} style={{ padding: 16 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: "var(--nls-text-subtle)", textTransform: "uppercase", letterSpacing: ".06em" }}>{k.label}</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 6 }}>
                <span style={{ fontSize: 32, fontWeight: 600, color: "var(--nls-text-strong)", letterSpacing: "-0.02em" }} className="nls-num">{k.value}</span>
                {k.trend && <span style={{ fontSize: 11, fontWeight: 500, color: "var(--nls-success)" }}>{k.trend}</span>}
              </div>
              <div style={{ fontSize: 12, color: "var(--nls-text-muted)", marginTop: 2 }}>{k.sub}</div>
            </Card>
          ))}
        </div>

        {/* Tiles grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          <HubTile
            icon="table" title="Schedule editor"
            sub="Assign staff to providers and dates."
            status={<Badge tone="warning" size="sm" dot>2 unstaffed</Badge>}
            stat={{ value: "—", label: "Open editor" }}
            primaryAction="Edit schedule"
          />
          <HubTile
            icon="inbox" title="Swap approvals" tone="warning"
            sub="Trades that need a manager to sign off."
            status={<Badge tone="warning" size="sm" dot>3 pending</Badge>}
            stat={{ value: "3", label: "awaiting review · oldest 6h" }}
            primaryAction="Review queue"
          />
          <HubTile
            icon="calendar" title="Provider availability"
            sub="Block PTO, conferences, holidays."
            status={<Badge tone="neutral" size="sm">Up to date</Badge>}
            stat={{ value: "2", label: "PTO blocks this month" }}
            primaryAction="Open calendar"
          />
          <HubTile
            icon="grid" title="Pairing rules"
            sub="Default staff↔provider matchups per weekday."
            status={<Badge tone="neutral" size="sm">28 rules</Badge>}
            stat={{ value: "3", label: "rules touched this week" }}
            primaryAction="Edit rules"
          />
          <HubTile
            icon="sparkle" title="Balance report" tone="accent"
            sub="Staffing ratios across providers and days."
            status={<Badge tone="warning" size="sm" dot>2 below target</Badge>}
            stat={{ value: "4.3", label: "avg MAs / provider · target 5" }}
            primaryAction="View report"
          />
          <HubTile
            icon="book" title="Audit log"
            sub="Every assignment, swap, approval, and edit."
            status={<Badge tone="neutral" size="sm">142 events today</Badge>}
            stat={{ value: "142", label: "events today · most by Sasha" }}
            primaryAction="Open log"
          />
        </div>

        {/* Recent activity */}
        <Card padded={false} style={{ marginTop: 18 }}>
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--nls-divider)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>Recent activity</div>
              <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>Last 24 hours</div>
            </div>
            <Button variant="ghost" size="sm">View all</Button>
          </div>
          {[
            { who: "Theo Walsh", hue: "var(--nls-role-rn)", initials: "TW", verb: "posted a swap for", what: "Fri Mar 21 · Dr. Hale", when: "2h ago", tone: "warning" },
            { who: "Aisha Bello", hue: "var(--nls-role-ma)", initials: "AB", verb: "received 2 proposals on", what: "Mon Mar 17 · Dr. Okafor", when: "5h ago", tone: "accent" },
            { who: "You",         hue: "var(--nls-text-muted)", initials: "ML", verb: "approved swap", what: "Ren Tanaka ↔ Camila Ortiz", when: "6h ago", tone: "success" },
            { who: "System",       hue: "var(--nls-text-subtle)", initials: "•", verb: "flagged conflict on", what: "Ap-200 (double-book)", when: "8h ago", tone: "danger" },
          ].map((row, i) => (
            <div key={i} style={{ padding: "12px 18px", display: "flex", alignItems: "center", gap: 12, borderBottom: i < 3 ? "1px solid var(--nls-divider)" : "none" }}>
              <Avatar initials={row.initials} hue={row.hue} size={26} />
              <div style={{ flex: 1, fontSize: 13, color: "var(--nls-text)" }}>
                <span style={{ fontWeight: 500, color: "var(--nls-text-strong)" }}>{row.who}</span>{" "}
                <span style={{ color: "var(--nls-text-muted)" }}>{row.verb}</span>{" "}
                <span style={{ fontWeight: 500 }}>{row.what}</span>
              </div>
              <Badge tone={row.tone} size="sm" dot>{row.when}</Badge>
            </div>
          ))}
        </Card>
      </div>
    </div>
  </Shell>
);

// ── Admin schedule editor ─────────────────────────────────────────
const ProvOptions = ["pat", "oka", "rom", "che", "rey", "hal", "boa"];

const EditorCell = ({ provId, dayIdx, dirty, editing }) => {
  if (editing) {
    return (
      <div style={{
        position: "relative",
        padding: 0, height: "100%", minHeight: 44,
      }}>
        <div style={{
          padding: "6px 8px", borderRadius: 6,
          border: "2px solid var(--nls-accent)",
          background: "var(--nls-surface)",
          boxShadow: "var(--nls-shadow-pop)",
          fontSize: 13, color: "var(--nls-text-strong)",
          display: "flex", alignItems: "center", gap: 6,
        }}>
          <Icon name="search" size={12} color="var(--nls-text-muted)" />
          <span>Dr…</span>
        </div>
        <div style={{
          position: "absolute", top: "100%", left: 0, marginTop: 4, width: 200,
          background: "var(--nls-surface)", border: "1px solid var(--nls-border-strong)",
          borderRadius: 8, boxShadow: "var(--nls-shadow-pop)",
          padding: 4, zIndex: 5,
        }}>
          {APROVS.slice(0, 5).map((p, i) => (
            <div key={p.id} style={{
              padding: "6px 8px", borderRadius: 5, fontSize: 12,
              background: i === 0 ? "var(--nls-accent-soft)" : "transparent",
              color: i === 0 ? "var(--nls-text-strong)" : "var(--nls-text)",
              display: "flex", alignItems: "center", gap: 8, cursor: "pointer",
            }}>
              <span style={{ width: 4, height: 18, borderRadius: 2, background: p.color }} />
              <span style={{ flex: 1, fontWeight: i === 0 ? 500 : 400 }}>{p.name}</span>
              {i === 0 && <Kbd>↵</Kbd>}
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (provId === null) return <AssignmentCell tone="empty" label="Off" compact />;
  if (provId === "—")  return <AssignmentCell tone="holiday" label="—" compact />;
  const p = providers.find((x) => x.id === provId);
  return (
    <div style={{
      padding: "6px 8px", borderRadius: 6,
      background: dirty ? "var(--nls-warning-soft)" : "var(--nls-surface)",
      border: `1px solid ${dirty ? "var(--nls-warning)" : "var(--nls-border)"}`,
      display: "flex", alignItems: "center", gap: 6,
      fontSize: 12.5, color: "var(--nls-text-strong)", fontWeight: 500,
      cursor: "pointer", position: "relative",
    }}>
      <span style={{ width: 4, height: 18, borderRadius: 2, background: p.color, flex: "0 0 4px" }} />
      <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.short}</span>
      {dirty && <span style={{ width: 6, height: 6, borderRadius: 3, background: "var(--nls-warning)" }} />}
    </div>
  );
};

const AdminEditorArtboard = ({ theme = "light", role = "manager" }) => (
  <Shell theme={theme} role={role} active="admin-editor" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0", display: "flex", flexDirection: "column" }}>
      <Topbar
        title="Schedule editor"
        subtitle="Week of Mar 17 — assign staff to providers"
        breadcrumbs={["Manage", "Schedule"]}
      />

      <div style={{ padding: "16px 24px 0", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <Input placeholder="Find staff…" icon="search" style={{ width: 220 }} />
          <Button variant="secondary" size="md" icon="filter">All roles</Button>
          <Button variant="ghost" size="md" icon="sparkle">Auto-fill from rules</Button>
          <Button variant="ghost" size="md">Copy from last week</Button>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <Badge tone="warning" dot>3 unsaved changes</Badge>
          <Button variant="ghost" size="md">Discard</Button>
          <Button variant="primary" size="md" icon="check">Publish</Button>
        </div>
      </div>

      <div style={{ padding: "16px 24px 24px" }}>
        <Card padded={false} style={{ overflow: "hidden" }}>
          <div style={{
            display: "grid", gridTemplateColumns: "200px repeat(5, 1fr)",
            background: "var(--nls-bg-tint)", borderBottom: "1px solid var(--nls-divider)",
            position: "sticky", top: 0, zIndex: 2,
          }}>
            <div style={{ padding: "10px 14px", fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>
              Staff
            </div>
            {ADAYS.map((d, i) => (
              <div key={d} style={{
                padding: "10px 12px",
                fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase",
                color: "var(--nls-text-subtle)",
                borderLeft: "1px solid var(--nls-divider)",
                display: "flex", alignItems: "center", justifyContent: "space-between",
              }}>
                <span>{d} · <span className="nls-num" style={{ fontWeight: 500, textTransform: "none", letterSpacing: 0 }}>{ADATES[i]}</span></span>
                <button style={{ ...chevBtnSm }}><Icon name="moreH" size={12} color="var(--nls-text-muted)" /></button>
              </div>
            ))}
          </div>

          {ASTAFF.slice(0, 8).map((person, ri) => {
            const dirtyKey = (ri === 1 && 3) || (ri === 4 && 2) || (ri === 2 && 4);
            return (
              <div key={person.id} style={{
                display: "grid", gridTemplateColumns: "200px repeat(5, 1fr)",
                borderBottom: "1px solid var(--nls-divider)",
                background: ri === 1 ? "var(--nls-warning-soft)" : "transparent",
              }}>
                <div style={{
                  padding: "8px 14px", display: "flex", alignItems: "center", gap: 10,
                  borderRight: "1px solid var(--nls-divider)",
                }}>
                  <Icon name="drag" size={14} color="var(--nls-text-subtle)" style={{ cursor: "grab" }} />
                  <Avatar initials={person.initials} hue={`var(--nls-role-${person.role.toLowerCase() === "front" ? "front" : person.role.toLowerCase()})`} size={26} />
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 500, color: "var(--nls-text-strong)" }}>{person.first}</div>
                    <div style={{ fontSize: 10.5, color: "var(--nls-text-muted)" }}>{person.role}</div>
                  </div>
                  <button style={{ ...chevBtnSm }}><Icon name="moreH" size={12} color="var(--nls-text-muted)" /></button>
                </div>
                {ADAYS.map((_, di) => (
                  <div key={di} style={{ padding: 6, borderLeft: "1px solid var(--nls-divider)" }}>
                    <EditorCell
                      provId={AROSTER[person.id][di]}
                      dayIdx={di}
                      dirty={dirtyKey && di === dirtyKey - 1}
                      editing={ri === 4 && di === 2}
                    />
                  </div>
                ))}
              </div>
            );
          })}
        </Card>

        {/* Inline insights bar */}
        <div style={{
          marginTop: 14,
          display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12,
        }}>
          <Card padded={false} style={{ padding: 14, display: "flex", gap: 12, alignItems: "center", borderColor: "var(--nls-warning)" }}>
            <Icon name="alert" size={18} color="var(--nls-warning)" />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)" }}>Pairing rule violated</div>
              <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>Devon should pair with Dr. Reyes on Wed (rule R-12).</div>
            </div>
            <Button variant="secondary" size="sm">Fix</Button>
          </Card>
          <Card padded={false} style={{ padding: 14, display: "flex", gap: 12, alignItems: "center", borderColor: "var(--nls-accent)" }}>
            <Icon name="sparkle" size={18} color="var(--nls-accent)" />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)" }}>Auto-fill suggestion</div>
              <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>Apply Mar 10 layout to fill 7 blank cells. 0 conflicts.</div>
            </div>
            <Button variant="primary" size="sm">Preview</Button>
          </Card>
        </div>
      </div>
    </div>
  </Shell>
);

const chevBtnSm = {
  width: 22, height: 22, border: "none", background: "transparent",
  borderRadius: 4, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
};

// ── Admin approvals queue ─────────────────────────────────────────
const AdminApprovalsArtboard = ({ theme = "light", role = "manager" }) => (
  <Shell theme={theme} role={role} active="approvals" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0" }}>
      <Topbar
        title="Swap approvals"
        subtitle="3 pending · oldest waiting 6h"
        hideWeek
      />
      <div style={{ padding: "20px 24px 32px", display: "flex", flexDirection: "column", gap: 14 }}>
        {pendingApprovals.map((a) => (
          <Card key={a.id} padded={false} style={{ padding: 18 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>#{a.id}</span>
                <Badge tone={a.conflict ? "danger" : "warning"} size="sm" dot>{a.conflict ? "Conflict" : "Pending"}</Badge>
                <span style={{ fontSize: 11.5, color: "var(--nls-text-subtle)" }}>Submitted {a.submitted}</span>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <Button variant="danger" size="sm">Reject</Button>
                <Button variant="primary" size="sm" icon="check" disabled={a.conflict}>Approve</Button>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 32px 1fr", gap: 12, alignItems: "center" }}>
              <ApprovalSide who={a.a} date={a.aDate} prov={a.aProv} dir="gives" />
              <div style={{ display: "flex", justifyContent: "center", color: "var(--nls-text-subtle)" }}>
                <Icon name="swap" size={20} />
              </div>
              <ApprovalSide who={a.b} date={a.bDate} prov={a.bProv} dir="gives" />
            </div>
            {a.conflict && (
              <div style={{
                marginTop: 12, padding: "10px 12px", borderRadius: 8,
                background: "var(--nls-danger-soft)", color: "var(--nls-danger)",
                border: "1px solid var(--nls-danger)", borderLeftWidth: 3,
                fontSize: 12.5, display: "flex", alignItems: "center", gap: 8,
              }}>
                <Icon name="alert" size={14} /> {a.conflictNote}
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  </Shell>
);

const ApprovalSide = ({ who, date, prov, dir }) => {
  const person = ASTAFF.find((s) => s.name === who) || { initials: who.split(" ").map((p) => p[0]).join(""), role: "MA", hue: "var(--nls-role-ma)" };
  return (
    <div style={{
      padding: 12, background: "var(--nls-bg-tint)", borderRadius: 10,
      display: "flex", flexDirection: "column", gap: 8, border: "1px solid var(--nls-divider)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <Avatar initials={person.initials || who.split(" ").map((p) => p[0]).join("")} hue={person.hue || "var(--nls-role-ma)"} size={26} />
        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)" }}>{who}</div>
      </div>
      <div style={{ fontSize: 11, color: "var(--nls-text-subtle)", letterSpacing: ".06em", textTransform: "uppercase", fontWeight: 600 }}>{dir === "gives" ? "Gives up" : "Receives"}</div>
      <div className="nls-num" style={{ fontSize: 15, fontWeight: 600, color: "var(--nls-text-strong)" }}>{date}</div>
      <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{prov}</div>
    </div>
  );
};

// ── Balance report ────────────────────────────────────────────────
const BalanceArtboard = ({ theme = "light" }) => (
  <Shell theme={theme} active="balance" topbar={null} subnav={null}>
    <div style={{ margin: "-20px -24px 0" }}>
      <Topbar title="Balance report" subtitle="Provider coverage · week of Mar 17" hideWeek />

      <div style={{ padding: "20px 24px 32px" }}>
        <Card padded={false}>
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--nls-divider)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--nls-text-strong)" }}>Provider coverage this week</div>
              <div style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>Target: 5 days fully paired per provider</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <Button variant="ghost" size="sm">Export CSV</Button>
              <Button variant="secondary" size="sm" icon="calendar">Compare weeks</Button>
            </div>
          </div>
          <div style={{
            display: "grid", gridTemplateColumns: "1.4fr 80px 1fr 60px 1.2fr",
            padding: "10px 18px", background: "var(--nls-bg-tint)",
            fontSize: 10.5, fontWeight: 600, color: "var(--nls-text-subtle)",
            textTransform: "uppercase", letterSpacing: ".06em",
          }}>
            <span>Provider</span>
            <span>Ratio</span>
            <span>5-week trend</span>
            <span style={{ textAlign: "right" }}>Avg</span>
            <span>Status</span>
          </div>
          {balance.map((b, i) => (
            <div key={b.prov} style={{
              display: "grid", gridTemplateColumns: "1.4fr 80px 1fr 60px 1.2fr",
              padding: "12px 18px", alignItems: "center",
              borderBottom: i < balance.length - 1 ? "1px solid var(--nls-divider)" : "none",
            }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>{b.prov}</span>
              <span className="nls-num" style={{ fontSize: 14, fontWeight: 600, color: b.status === "ok" ? "var(--nls-success)" : b.status === "warn" ? "var(--nls-warning)" : "var(--nls-danger)" }}>{b.ratio}</span>
              <Sparkline values={b.weeks} status={b.status} />
              <span className="nls-num" style={{ fontSize: 12.5, color: "var(--nls-text-muted)", textAlign: "right" }}>
                {(b.weeks.reduce((s, n) => s + n, 0) / b.weeks.length).toFixed(1)}
              </span>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <StatusChip status={b.status} size="sm" />
                {b.note && <span style={{ fontSize: 11.5, color: "var(--nls-text-muted)" }}>{b.note}</span>}
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  </Shell>
);

const Sparkline = ({ values, status }) => {
  const w = 120, h = 26;
  const max = Math.max(...values, 5);
  const min = 0;
  const stroke = status === "ok" ? "var(--nls-success)" : status === "warn" ? "var(--nls-warning)" : "var(--nls-danger)";
  const pts = values.map((v, i) => `${(i / (values.length - 1)) * (w - 4) + 2},${h - 3 - ((v - min) / (max - min)) * (h - 6)}`);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <line x1="0" y1={h - 3 - ((5 - min) / (max - min)) * (h - 6)} x2={w} y2={h - 3 - ((5 - min) / (max - min)) * (h - 6)} stroke="var(--nls-divider)" strokeDasharray="2 3" />
      <polyline fill="none" stroke={stroke} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" points={pts.join(" ")} />
      {pts.map((p, i) => {
        const [x, y] = p.split(",");
        return <circle key={i} cx={x} cy={y} r={i === pts.length - 1 ? 2.5 : 1.6} fill={i === pts.length - 1 ? stroke : "var(--nls-surface)"} stroke={stroke} strokeWidth="1.4" />;
      })}
    </svg>
  );
};

Object.assign(window, { AdminHubArtboard, AdminEditorArtboard, AdminApprovalsArtboard, BalanceArtboard });
