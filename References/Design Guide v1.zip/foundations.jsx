// Foundations — design system reference cards
// Color (light + dark), typography, spacing, radius, shadow, icons.

const SwatchRow = ({ label, varName, hex }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderBottom: "1px solid var(--nls-divider)" }}>
    <div style={{
      width: 36, height: 36, borderRadius: 8,
      background: `var(${varName})`,
      boxShadow: "inset 0 0 0 1px var(--nls-border)",
      flex: "0 0 auto",
    }} />
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 500, color: "var(--nls-text-strong)" }}>{label}</div>
      <div className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>{varName}</div>
    </div>
    {hex && <div className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-muted)" }}>{hex}</div>}
  </div>
);

const ColorGroup = ({ title, items }) => (
  <div>
    <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)", marginBottom: 4 }}>{title}</div>
    {items.map((it, i) => <SwatchRow key={i} {...it} />)}
  </div>
);

// ── Brand / cover ─────────────────────────────────────────────────
const BrandCover = () => (
  <div className="nls-scope" style={{ width: "100%", height: "100%", padding: 40, display: "flex", flexDirection: "column", justifyContent: "space-between", background: "var(--nls-bg)" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <Logo size={28} />
      <div style={{ fontSize: 15, fontWeight: 600, color: "var(--nls-text-strong)" }}>Next Level Scheduler</div>
    </div>
    <div>
      <div style={{ fontSize: 13, color: "var(--nls-accent)", fontWeight: 500, marginBottom: 12 }}>Design system · v1</div>
      <div style={{ fontSize: 44, fontWeight: 600, lineHeight: 1.05, letterSpacing: "-0.02em", color: "var(--nls-text-strong)", marginBottom: 16, textWrap: "balance" }}>
        Calm tools for the
        <br />people who make
        <br />a clinic run.
      </div>
      <div style={{ fontSize: 15, color: "var(--nls-text-muted)", lineHeight: 1.55, maxWidth: 460 }}>
        A multi-role scheduling platform built on warm neutrals, generous spacing, and unambiguous status. Notion's restraint, Linear's discipline, healthcare's patience.
      </div>
    </div>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {["Clarity first", "Status at a glance", "Role-appropriate density", "Warm professionalism", "Mobile-ready"].map((p) => (
        <Badge key={p} tone="neutral" size="md">{p}</Badge>
      ))}
    </div>
  </div>
);

// Simple wordmark logo
const Logo = ({ size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <rect x="2" y="2" width="28" height="28" rx="8" fill="var(--nls-accent)" />
    <path d="M9 22V10h2.5l6.5 8.5V10h2.5v12H17.9L11.4 13.5V22H9Z" fill="#fff" />
    <circle cx="23.5" cy="22.5" r="2.2" fill="#fff" />
  </svg>
);

// ── Color (light) ─────────────────────────────────────────────────
const ColorArtboard = ({ theme = "light" }) => (
  <div className="nls-scope" data-theme={theme} style={{ width: "100%", height: "100%", padding: 28, overflow: "auto", background: "var(--nls-bg)" }}>
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)", marginBottom: 4 }}>
        Color · {theme}
      </div>
      <div style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)" }}>
        {theme === "light" ? "Warm neutrals" : "Late-shift neutrals"}
      </div>
      <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)", marginTop: 4, lineHeight: 1.5 }}>
        Paper-warm bg, near-black ink, Notion-blue accent. No pure black, no pure white — softer on the eyes during long shifts.
      </div>
    </div>

    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 22 }}>
      <ColorGroup title="Surface" items={[
        { label: "bg",          varName: "--nls-bg" },
        { label: "bg-tint",     varName: "--nls-bg-tint" },
        { label: "surface",     varName: "--nls-surface" },
        { label: "surface-hover", varName: "--nls-surface-hover" },
        { label: "surface-sunken", varName: "--nls-surface-sunken" },
      ]} />
      <ColorGroup title="Text" items={[
        { label: "text-strong", varName: "--nls-text-strong" },
        { label: "text",        varName: "--nls-text" },
        { label: "text-muted",  varName: "--nls-text-muted" },
        { label: "text-subtle", varName: "--nls-text-subtle" },
      ]} />
      <ColorGroup title="Accent (Notion blue)" items={[
        { label: "accent",        varName: "--nls-accent" },
        { label: "accent-hover",  varName: "--nls-accent-hover" },
        { label: "accent-soft",   varName: "--nls-accent-soft" },
        { label: "accent-strong", varName: "--nls-accent-strong" },
      ]} />
      <ColorGroup title="Semantic" items={[
        { label: "success", varName: "--nls-success" },
        { label: "warning", varName: "--nls-warning" },
        { label: "danger",  varName: "--nls-danger" },
        { label: "info",    varName: "--nls-info" },
      ]} />
      <ColorGroup title="Roles" items={[
        { label: "RN — teal",      varName: "--nls-role-rn" },
        { label: "MA — violet",    varName: "--nls-role-ma" },
        { label: "Scribe — amber", varName: "--nls-role-scribe" },
        { label: "Front — pink",   varName: "--nls-role-front" },
      ]} />
      <ColorGroup title="Border" items={[
        { label: "border",         varName: "--nls-border" },
        { label: "border-strong",  varName: "--nls-border-strong" },
        { label: "divider",        varName: "--nls-divider" },
      ]} />
    </div>
  </div>
);

// ── Typography ────────────────────────────────────────────────────
const TypeArtboard = () => (
  <div className="nls-scope" style={{ width: "100%", height: "100%", padding: 32, background: "var(--nls-bg)", overflow: "auto" }}>
    <div style={{ marginBottom: 22 }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>Type</div>
      <div style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)", marginTop: 2 }}>Geist Sans · Geist Mono</div>
      <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)", marginTop: 4 }}>
        14px base. Tight headings (-0.01em). Mono reserved for dates, codes, ratios.
      </div>
    </div>

    {[
      ["Display / 52", 52, 600, "Tue, March 18", "var(--nls-text-strong)"],
      ["Heading 1 / 38", 38, 600, "This week's schedule"],
      ["Heading 2 / 30", 30, 600, "Open swap requests"],
      ["Heading 3 / 24", 24, 600, "Dr. Patel — Family Med"],
      ["Title / 20", 20, 600, "Propose a swap"],
      ["Body L / 17", 17, 400, "Three teammates posted shifts on the board this morning."],
      ["Body / 14 base", 14, 400, "Pick one of your eligible assignments to offer in return."],
      ["Caption / 12", 12, 500, "POSTED 2H AGO · EXPIRES IN 18H", "var(--nls-text-muted)"],
    ].map(([label, fs, fw, sample, color]) => (
      <div key={label} style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: 24, alignItems: "baseline", padding: "10px 0", borderTop: "1px solid var(--nls-divider)" }}>
        <div className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-subtle)", paddingTop: 6 }}>{label}</div>
        <div style={{ fontSize: fs, fontWeight: fw, color: color || "var(--nls-text)", letterSpacing: fs > 20 ? "-0.015em" : 0, lineHeight: fs > 30 ? 1.05 : 1.4 }}>
          {sample}
        </div>
      </div>
    ))}

    <div style={{ marginTop: 24, padding: 16, background: "var(--nls-bg-tint)", borderRadius: 10, border: "1px solid var(--nls-divider)" }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)", marginBottom: 8 }}>Mono · dates &amp; codes</div>
      <div className="nls-mono" style={{ fontSize: 18, color: "var(--nls-text)", display: "flex", gap: 28, flexWrap: "wrap" }}>
        <span>2026-03-18</span>
        <span>08:00 – 17:00</span>
        <span>#p-1042</span>
        <span>5/5</span>
      </div>
    </div>
  </div>
);

// ── Spacing / radius / shadow ─────────────────────────────────────
const SpacingArtboard = () => (
  <div className="nls-scope" style={{ width: "100%", height: "100%", padding: 32, background: "var(--nls-bg)", overflow: "auto" }}>
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>Spacing &amp; shape</div>
      <div style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)", marginTop: 2 }}>4px base · multiples of 4</div>
    </div>

    <SectionTitle style={{ marginBottom: 8 }}>Spacing scale</SectionTitle>
    <div style={{ display: "grid", gridTemplateColumns: "60px 1fr 80px", rowGap: 8, columnGap: 16, alignItems: "center", marginBottom: 22 }}>
      {[
        ["s-1", 4], ["s-2", 8], ["s-3", 12], ["s-4", 16],
        ["s-5", 20], ["s-6", 24], ["s-8", 32], ["s-10", 40],
      ].map(([t, n]) => (
        <React.Fragment key={t}>
          <div className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>--nls-{t}</div>
          <div style={{ height: 8, background: "var(--nls-accent-soft)", borderLeft: "2px solid var(--nls-accent)", width: n * 4 }} />
          <div className="nls-mono" style={{ fontSize: 11, color: "var(--nls-text-muted)" }}>{n}px</div>
        </React.Fragment>
      ))}
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Radius</SectionTitle>
    <div style={{ display: "flex", gap: 14, marginBottom: 24 }}>
      {[["r-1", 4], ["r-2", 6], ["r-3", 8], ["r-4", 12], ["r-5", 16], ["pill", 999]].map(([t, n]) => (
        <div key={t} style={{ textAlign: "center" }}>
          <div style={{
            width: 56, height: 56, background: "var(--nls-surface)",
            borderRadius: n, border: "1px solid var(--nls-border-strong)", marginBottom: 6,
          }} />
          <div className="nls-mono" style={{ fontSize: 10.5, color: "var(--nls-text-muted)" }}>{t}</div>
        </div>
      ))}
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Elevation</SectionTitle>
    <div style={{ display: "flex", gap: 18 }}>
      {[["shadow-1", "var(--nls-shadow-1)"], ["shadow-2", "var(--nls-shadow-2)"], ["shadow-3", "var(--nls-shadow-3)"], ["pop", "var(--nls-shadow-pop)"]].map(([t, sh]) => (
        <div key={t} style={{ textAlign: "center" }}>
          <div style={{ width: 80, height: 56, background: "var(--nls-surface)", borderRadius: 8, boxShadow: sh, marginBottom: 6 }} />
          <div className="nls-mono" style={{ fontSize: 10.5, color: "var(--nls-text-muted)" }}>{t}</div>
        </div>
      ))}
    </div>
  </div>
);

// ── Buttons & form controls ────────────────────────────────────────
const ButtonsArtboard = () => (
  <div className="nls-scope" style={{ width: "100%", height: "100%", padding: 30, background: "var(--nls-bg)", overflow: "auto" }}>
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>Components</div>
      <div style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)", marginTop: 2 }}>Buttons &amp; inputs</div>
    </div>

    {[
      ["Primary", "primary"],
      ["Secondary", "secondary"],
      ["Ghost", "ghost"],
      ["Danger", "danger"],
    ].map(([label, v]) => (
      <div key={v} style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 16, alignItems: "center", padding: "10px 0", borderBottom: "1px solid var(--nls-divider)" }}>
        <div style={{ fontSize: 12, color: "var(--nls-text-muted)" }}>{label}</div>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <Button variant={v} size="sm">Small</Button>
          <Button variant={v} size="md">Medium</Button>
          <Button variant={v} size="lg" icon="plus">With icon</Button>
        </div>
      </div>
    ))}

    <div style={{ marginTop: 20, marginBottom: 8 }}>
      <SectionTitle>Inputs</SectionTitle>
    </div>
    <div style={{ display: "flex", flexDirection: "column", gap: 10, maxWidth: 380 }}>
      <Input placeholder="Filter by name…" icon="search" />
      <Input placeholder="Friday, Mar 21" icon="calendar" />
      <label style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        height: 34, padding: "0 10px",
        background: "var(--nls-surface)", border: "1px solid var(--nls-border-strong)",
        borderRadius: 8, fontSize: 13, color: "var(--nls-text)",
      }}>
        <span>Dr. Patel — Family Med</span>
        <Icon name="chevronDown" size={14} color="var(--nls-text-muted)" />
      </label>
    </div>
  </div>
);

// ── Badges, statuses, role labels ─────────────────────────────────
const BadgesArtboard = () => (
  <div className="nls-scope" style={{ width: "100%", height: "100%", padding: 30, background: "var(--nls-bg)", overflow: "auto" }}>
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>Components</div>
      <div style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)", marginTop: 2 }}>Status, role &amp; metadata</div>
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Swap status</SectionTitle>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
      {["open", "has-proposals", "pending", "approved", "expiring", "expired", "rejected"].map((s) => (
        <StatusChip key={s} status={s} />
      ))}
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Staffing</SectionTitle>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
      <StatusChip status="ok" />
      <StatusChip status="warn" />
      <StatusChip status="alert" />
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Role labels</SectionTitle>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 22 }}>
      <Badge tone="rn" dot>RN</Badge>
      <Badge tone="ma" dot>MA</Badge>
      <Badge tone="scribe" dot>Scribe</Badge>
      <Badge tone="front" dot>Front Desk</Badge>
      <Badge tone="neutral">Manager</Badge>
      <Badge tone="accent" solid>Developer</Badge>
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Assignment cells</SectionTitle>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 22 }}>
      {[
        { tone: "default", label: "Dr. Patel", sub: "Family Med" },
        { tone: "swap-open", label: "Dr. Hale", sub: "Endocrinology", chip: "Posted" },
        { tone: "swap-pending", label: "Dr. Okafor", sub: "Cardiology", chip: "Pending" },
        { tone: "approved", label: "Dr. Reyes", sub: "Internal Med", chip: "Approved" },
        { tone: "empty", label: "—", sub: "Unassigned" },
        { tone: "today", label: "Dr. Chen", sub: "Pediatrics · Today" },
      ].map((c, i) => (
        <AssignmentCell key={i} {...c} />
      ))}
    </div>

    <SectionTitle style={{ marginBottom: 10 }}>Avatars</SectionTitle>
    <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
      <Avatar initials="ML" hue="var(--nls-role-ma)" size={28} />
      <Avatar initials="DB" hue="var(--nls-role-rn)" size={32} />
      <Avatar initials="PS" hue="var(--nls-role-scribe)" size={40} />
      <AvatarStack people={[
        { initials: "TW", hue: "var(--nls-role-rn)" },
        { initials: "NA", hue: "var(--nls-role-ma)" },
        { initials: "RT", hue: "var(--nls-role-scribe)" },
        { initials: "CO", hue: "var(--nls-role-ma)" },
        { initials: "SK", hue: "var(--nls-role-rn)" },
      ]} max={4} />
    </div>
  </div>
);

// Re-usable assignment cell — referenced from many screens
const AssignmentCell = ({ tone = "default", label, sub, chip, compact, today }) => {
  const base = {
    background: "var(--nls-surface)",
    border: "1px solid var(--nls-border)",
    borderRadius: 8,
    padding: compact ? "8px 10px" : "10px 12px",
  };
  const tones = {
    default: { ...base },
    today: { ...base, background: "var(--nls-accent-soft)", borderColor: "var(--nls-accent)" },
    empty: { ...base, background: "transparent", borderStyle: "dashed", borderColor: "var(--nls-border-strong)", color: "var(--nls-text-subtle)" },
    "swap-open": { ...base, background: "color-mix(in oklab, var(--nls-warning-soft) 70%, var(--nls-surface))", borderColor: "var(--nls-warning)", borderStyle: "dashed" },
    "swap-pending": { ...base, background: "var(--nls-accent-soft)", borderColor: "var(--nls-accent)", borderStyle: "dashed" },
    approved: { ...base, background: "var(--nls-success-soft)", borderColor: "var(--nls-success)" },
    rejected: { ...base, background: "var(--nls-danger-soft)", borderColor: "var(--nls-danger)" },
    holiday:  { ...base, background: "var(--nls-bg-tint)", color: "var(--nls-text-muted)" },
  };
  return (
    <div style={tones[tone] || tones.default}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 6 }}>
        <div style={{ fontSize: compact ? 12 : 13, fontWeight: 500, color: tone === "empty" ? "var(--nls-text-subtle)" : "var(--nls-text-strong)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</div>
        {chip && <Badge tone={tone === "swap-pending" ? "accent" : tone === "swap-open" ? "warning" : tone === "approved" ? "success" : "neutral"} size="sm" dot>{chip}</Badge>}
      </div>
      {sub && <div style={{ fontSize: 11, color: "var(--nls-text-muted)", marginTop: 2 }}>{sub}</div>}
    </div>
  );
};

// ── Icons gallery ─────────────────────────────────────────────────
const IconsArtboard = () => {
  const names = ["calendar","grid","table","swap","inbox","user","users","shield","settings",
                 "plus","search","bell","filter","alert","clock","check","x","arrowRight","drag","sun","moon","sparkle"];
  return (
    <div className="nls-scope" style={{ width: "100%", height: "100%", padding: 30, background: "var(--nls-bg)", overflow: "auto" }}>
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", color: "var(--nls-text-subtle)" }}>Iconography</div>
        <div style={{ fontSize: 18, fontWeight: 600, color: "var(--nls-text-strong)", marginTop: 2 }}>Inline SVG · 1.6 stroke</div>
        <div style={{ fontSize: 12.5, color: "var(--nls-text-muted)", marginTop: 4 }}>Notion-flavored line art. 20px viewBox, defaults to 16px render, currentColor.</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 4 }}>
        {names.map((n) => (
          <div key={n} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, padding: "12px 6px", borderRadius: 8, border: "1px solid var(--nls-divider)", background: "var(--nls-surface)" }}>
            <Icon name={n} size={20} color="var(--nls-text)" />
            <div className="nls-mono" style={{ fontSize: 10, color: "var(--nls-text-subtle)" }}>{n}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { BrandCover, ColorArtboard, TypeArtboard, SpacingArtboard, ButtonsArtboard, BadgesArtboard, IconsArtboard, AssignmentCell, Logo });
