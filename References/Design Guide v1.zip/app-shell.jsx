// App shell — sidebar (desktop) + topbar + mobile bottom nav.
// Used as a reusable layout for every desktop screen, plus stands alone as
// an artboard.

const { useState: useShellState } = React;

// ── Sidebar ───────────────────────────────────────────────────────
const SidebarItem = ({ icon, label, active, badge, sub }) => (
  <div
    style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: sub ? "5px 10px 5px 32px" : "6px 10px",
      borderRadius: 6, cursor: "pointer",
      fontSize: 13.5, fontWeight: active ? 500 : 400,
      color: active ? "var(--nls-text-strong)" : "var(--nls-text-muted)",
      background: active ? "var(--nls-surface-hover)" : "transparent",
      transition: "background .12s",
    }}
  >
    {icon && <Icon name={icon} size={16} color={active ? "var(--nls-text)" : "var(--nls-text-muted)"} />}
    <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</span>
    {badge != null && (
      <span style={{
        minWidth: 18, height: 18, padding: "0 5px",
        background: typeof badge === "number" && badge > 0 ? "var(--nls-accent)" : "var(--nls-neutral-soft)",
        color: typeof badge === "number" && badge > 0 ? "#fff" : "var(--nls-text-muted)",
        borderRadius: 9, fontSize: 10.5, fontWeight: 600,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
      }}>{badge}</span>
    )}
  </div>
);

const SidebarSection = ({ label, children, role }) => (
  <div style={{ marginBottom: 14 }}>
    {label && (
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "4px 10px 4px 10px",
        fontSize: 10.5, fontWeight: 600, letterSpacing: ".08em",
        textTransform: "uppercase", color: "var(--nls-text-subtle)",
      }}>
        <span>{label}</span>
        {role && <Badge tone={role === "Manager" ? "accent" : role === "Developer" ? "danger" : "neutral"} size="sm">{role}</Badge>}
      </div>
    )}
    <div style={{ display: "flex", flexDirection: "column", gap: 1, padding: "0 6px" }}>{children}</div>
  </div>
);

const Sidebar = ({ active = "schedule", role = "manager" }) => {
  const isManager = role === "manager" || role === "developer";
  const isDev = role === "developer";
  return (
    <aside style={{
      width: 232, flex: "0 0 232px",
      height: "100%", background: "var(--nls-bg-tint)",
      borderRight: "1px solid var(--nls-border)",
      display: "flex", flexDirection: "column",
      paddingTop: 10,
    }}>
      {/* workspace switcher */}
      <div style={{
        display: "flex", alignItems: "center", gap: 9,
        margin: "0 10px 14px", padding: "8px 8px",
        borderRadius: 8, cursor: "pointer",
      }}>
        <div style={{
          width: 26, height: 26, borderRadius: 6, background: "var(--nls-text-strong)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "var(--nls-bg)", fontSize: 13, fontWeight: 600,
        }}>R</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--nls-text-strong)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Riverside Clinic</div>
          <div style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>Multi-specialty · 42 staff</div>
        </div>
        <Icon name="chevronDown" size={13} color="var(--nls-text-subtle)" />
      </div>

      {/* search */}
      <div style={{ padding: "0 10px 12px" }}>
        <label style={{
          display: "flex", alignItems: "center", gap: 7,
          height: 28, padding: "0 9px",
          background: "var(--nls-surface)", border: "1px solid var(--nls-border)",
          borderRadius: 7, color: "var(--nls-text-muted)", fontSize: 12,
        }}>
          <Icon name="search" size={13} />
          <span style={{ flex: 1 }}>Search</span>
          <Kbd>⌘K</Kbd>
        </label>
      </div>

      <div style={{ flex: 1, overflowY: "auto" }}>
        <SidebarSection label="Workspace">
          <SidebarItem icon="home" label="Home" />
          <SidebarItem icon="bell" label="Inbox" badge={3} />
        </SidebarSection>

        <SidebarSection label="My work">
          <SidebarItem icon="calendar" label="My schedule" active={active === "schedule"} />
          <SidebarItem icon="swap"     label="Swap board"   active={active === "swap-board"} badge={6} />
          <SidebarItem icon="inbox"    label="My swaps"    active={active === "my-swaps"} badge={2} />
        </SidebarSection>

        {isManager && (
          <SidebarSection label="Manage" role={isDev ? "Developer" : "Manager"}>
            <SidebarItem icon="table"    label="Schedule editor"   active={active === "admin-editor"} />
            <SidebarItem icon="calendar" label="Provider availability" active={active === "providers"} />
            <SidebarItem icon="grid"     label="Pairing rules"     active={active === "rules"} />
            <SidebarItem icon="inbox"    label="Swap approvals"    active={active === "approvals"} badge={3} />
            <SidebarItem icon="sparkle"  label="Balance report"    active={active === "balance"} />
            <SidebarItem icon="book"     label="Audit log"         active={active === "audit"} />
          </SidebarSection>
        )}

        {isDev && (
          <SidebarSection label="Developer">
            <SidebarItem icon="users"    label="User accounts" />
            <SidebarItem icon="settings" label="System settings" />
          </SidebarSection>
        )}
      </div>

      {/* footer — user */}
      <div style={{ padding: "10px 10px 12px", borderTop: "1px solid var(--nls-divider)", display: "flex", alignItems: "center", gap: 10 }}>
        <Avatar initials="ML" hue="var(--nls-role-ma)" size={28} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 500, color: "var(--nls-text-strong)" }}>Maya Lin</div>
          <div style={{ fontSize: 11, color: "var(--nls-text-subtle)" }}>
            {role === "manager" ? "Manager · MA" : role === "developer" ? "Developer · MA" : "MA"}
          </div>
        </div>
        <Icon name="settings" size={15} color="var(--nls-text-subtle)" />
      </div>
    </aside>
  );
};

// ── Topbar ────────────────────────────────────────────────────────
const Topbar = ({ title, subtitle, week = "Mar 17 – 21", actions, breadcrumbs, hideWeek }) => (
  <header style={{
    height: 56, padding: "0 24px",
    display: "flex", alignItems: "center", gap: 16,
    borderBottom: "1px solid var(--nls-divider)",
    background: "var(--nls-bg)",
    flex: "0 0 56px",
  }}>
    <div style={{ display: "flex", flexDirection: "column", flex: 1, minWidth: 0 }}>
      {breadcrumbs && (
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11.5, color: "var(--nls-text-subtle)", marginBottom: 1 }}>
          {breadcrumbs.map((b, i) => (
            <React.Fragment key={i}>
              {i > 0 && <Icon name="chevronRight" size={10} />}
              <span style={{ color: i === breadcrumbs.length - 1 ? "var(--nls-text-muted)" : "var(--nls-text-subtle)" }}>{b}</span>
            </React.Fragment>
          ))}
        </div>
      )}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <h2 style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-0.01em" }}>{title}</h2>
        {subtitle && <span style={{ fontSize: 12.5, color: "var(--nls-text-muted)" }}>{subtitle}</span>}
      </div>
    </div>
    {!hideWeek && (
      <div style={{
        display: "flex", alignItems: "center", gap: 2,
        padding: 2, border: "1px solid var(--nls-border)", borderRadius: 8,
        background: "var(--nls-surface)",
      }}>
        <button style={chevBtn}><Icon name="chevronLeft" size={14} color="var(--nls-text-muted)" /></button>
        <span style={{ fontSize: 12.5, padding: "0 10px", fontWeight: 500, color: "var(--nls-text)" }} className="nls-num">
          Week of {week}
        </span>
        <button style={chevBtn}><Icon name="chevronRight" size={14} color="var(--nls-text-muted)" /></button>
      </div>
    )}
    {actions || (
      <>
        <button style={iconBtn}><Icon name="bell" size={16} color="var(--nls-text-muted)" /></button>
      </>
    )}
  </header>
);

const chevBtn = {
  width: 24, height: 24, border: "none", background: "transparent",
  borderRadius: 5, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
};
const iconBtn = {
  width: 32, height: 32, border: "1px solid var(--nls-border)", background: "var(--nls-surface)",
  borderRadius: 7, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
};

// ── Sub-nav (tab strip) ───────────────────────────────────────────
const SubNav = ({ tabs, active }) => (
  <div style={{
    display: "flex", gap: 4, padding: "0 24px",
    borderBottom: "1px solid var(--nls-divider)", height: 38, alignItems: "flex-end",
    flex: "0 0 38px",
  }}>
    {tabs.map((t) => {
      const isActive = t.id === active;
      return (
        <div key={t.id} style={{
          display: "flex", alignItems: "center", gap: 6,
          padding: "0 12px", height: 38,
          fontSize: 13, fontWeight: isActive ? 500 : 400,
          color: isActive ? "var(--nls-text-strong)" : "var(--nls-text-muted)",
          borderBottom: `2px solid ${isActive ? "var(--nls-text-strong)" : "transparent"}`,
          marginBottom: -1,
          cursor: "pointer",
        }}>
          {t.icon && <Icon name={t.icon} size={14} />}
          {t.label}
          {t.count != null && (
            <span style={{
              fontSize: 11, color: "var(--nls-text-subtle)",
              background: "var(--nls-neutral-soft)", borderRadius: 999,
              padding: "0 6px", lineHeight: "16px",
            }}>{t.count}</span>
          )}
        </div>
      );
    })}
  </div>
);

// ── Page wrapper that combines sidebar + topbar (+ optional subnav) ──
const Shell = ({ active, role = "manager", topbar, subnav, children, theme = "light" }) => (
  <div className="nls-scope" data-theme={theme} style={{
    width: "100%", height: "100%", display: "flex",
    background: "var(--nls-bg)", overflow: "hidden",
  }}>
    <Sidebar active={active} role={role} />
    <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
      {topbar}
      {subnav}
      <main style={{ flex: 1, overflow: "auto", padding: "20px 24px 32px" }}>{children}</main>
    </div>
  </div>
);

// ── Mobile bottom nav ─────────────────────────────────────────────
const BottomNav = ({ active }) => {
  const items = [
    { id: "schedule",   icon: "calendar", label: "Schedule" },
    { id: "swap-board", icon: "swap",     label: "Swaps", badge: 6 },
    { id: "my-swaps",   icon: "inbox",    label: "Inbox", badge: 2 },
    { id: "me",         icon: "user",     label: "Me" },
  ];
  return (
    <nav style={{
      display: "flex", height: 78, padding: "6px 8px 24px",
      borderTop: "1px solid var(--nls-divider)", background: "var(--nls-surface)",
    }}>
      {items.map((it) => {
        const isActive = it.id === active;
        return (
          <div key={it.id} style={{
            flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            gap: 3, position: "relative",
            color: isActive ? "var(--nls-accent)" : "var(--nls-text-muted)",
          }}>
            <div style={{ position: "relative" }}>
              <Icon name={it.icon} size={22} strokeWidth={isActive ? 1.9 : 1.6} />
              {it.badge && (
                <span style={{
                  position: "absolute", top: -3, right: -8,
                  minWidth: 16, height: 16, padding: "0 4px",
                  background: "var(--nls-accent)", color: "#fff",
                  borderRadius: 8, fontSize: 10, fontWeight: 600,
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  boxShadow: "0 0 0 2px var(--nls-surface)",
                }}>{it.badge}</span>
              )}
            </div>
            <span style={{ fontSize: 10.5, fontWeight: isActive ? 600 : 500 }}>{it.label}</span>
          </div>
        );
      })}
    </nav>
  );
};

// ── Mobile top header ──────────────────────────────────────────────
const MobileHeader = ({ title, leading, trailing, sub }) => (
  <header style={{
    height: sub ? 88 : 56, padding: "8px 16px",
    display: "flex", alignItems: "center", gap: 8,
    borderBottom: "1px solid var(--nls-divider)", background: "var(--nls-bg)",
  }}>
    {leading || <div style={{ width: 32 }} />}
    <div style={{ flex: 1, textAlign: sub ? "left" : "center" }}>
      <div style={{ fontSize: 15, fontWeight: 600, color: "var(--nls-text-strong)" }}>{title}</div>
      {sub && <div style={{ fontSize: 12, color: "var(--nls-text-muted)", marginTop: 2 }}>{sub}</div>}
    </div>
    {trailing || <div style={{ width: 32 }} />}
  </header>
);

// Status-bar shim (iOS-flavored)
const StatusBar = () => (
  <div style={{
    height: 44, padding: "0 22px",
    display: "flex", alignItems: "center", justifyContent: "space-between",
    fontFamily: "var(--nls-font-sans)",
    background: "var(--nls-bg)",
  }}>
    <span style={{ fontSize: 14, fontWeight: 600, color: "var(--nls-text-strong)" }}>9:41</span>
    <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--nls-text-strong)" }}>
      <svg width="16" height="11" viewBox="0 0 16 11" fill="currentColor"><rect x="0" y="6" width="3" height="5" rx="0.5"/><rect x="4.5" y="4" width="3" height="7" rx="0.5"/><rect x="9" y="2" width="3" height="9" rx="0.5"/><rect x="13.5" y="0" width="3" height="11" rx="0.5"/></svg>
      <svg width="14" height="10" viewBox="0 0 14 10" fill="none" stroke="currentColor" strokeWidth="1"><path d="M1 4a8 8 0 0 1 12 0M3.5 6a5 5 0 0 1 7 0"/><circle cx="7" cy="8.5" r="1" fill="currentColor"/></svg>
      <svg width="24" height="11" viewBox="0 0 24 11" fill="none" stroke="currentColor"><rect x="0.5" y="0.5" width="20" height="10" rx="2.5"/><rect x="2" y="2" width="14" height="7" rx="1" fill="currentColor"/><rect x="21" y="3.5" width="2" height="4" rx="1" fill="currentColor"/></svg>
    </div>
  </div>
);

// ── App-shell artboard (showcase) ─────────────────────────────────
const AppShellArtboard = ({ theme = "light", role = "manager" }) => (
  <Shell
    active="schedule"
    role={role}
    theme={theme}
    topbar={
      <Topbar
        title="My schedule"
        subtitle="Welcome back, Maya"
        breadcrumbs={["Workspace", "My work"]}
      />
    }
    subnav={<SubNav active="roster" tabs={[
      { id: "roster", icon: "table", label: "Roster" },
      { id: "month",  icon: "calendar", label: "Month" },
      { id: "matrix", icon: "grid", label: "Matrix" },
    ]} />}
  >
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, gap: 10, flexWrap: "wrap" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <Input placeholder="Filter staff…" icon="search" style={{ width: 220 }} />
        <Button variant="secondary" icon="filter">All providers</Button>
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <Button variant="ghost" icon="sparkle">Suggest swaps</Button>
        <Button variant="primary" icon="plus">Post a swap</Button>
      </div>
    </div>

    <Card padded={false}>
      <div style={{ padding: 20, color: "var(--nls-text-muted)", fontSize: 13 }}>
        <em style={{ fontStyle: "normal", color: "var(--nls-text-subtle)" }}>Schedule content goes here — see Roster artboard.</em>
      </div>
    </Card>
  </Shell>
);

const MobileFrame = ({ children, theme = "light", noStatus, w = 375, h = 812 }) => (
  <div className="nls-scope" data-theme={theme} style={{
    width: w, height: h, display: "flex", flexDirection: "column",
    background: "var(--nls-bg)", overflow: "hidden",
  }}>
    {!noStatus && <StatusBar />}
    {children}
  </div>
);

Object.assign(window, { Sidebar, SidebarItem, SidebarSection, Topbar, SubNav, Shell, BottomNav, MobileHeader, StatusBar, AppShellArtboard, MobileFrame });
